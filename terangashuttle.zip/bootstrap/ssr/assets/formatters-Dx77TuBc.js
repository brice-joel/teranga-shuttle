const formatDate = (date) => {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    hour: "2-digit",
    minute: "2-digit"
  }).format(d);
};
const isDateInPast = (date) => {
  return date < /* @__PURE__ */ new Date();
};
function calculateEndDate(dateDebut, dureeMinutes) {
  if (!dateDebut || isNaN(dureeMinutes)) {
    return "";
  }
  let date = new Date(dateDebut.replace(" ", "T"));
  date.setMinutes(date.getMinutes() + dureeMinutes);
  const pad = (n) => n.toString().padStart(2, "0");
  const annee = date.getFullYear();
  const mois = pad(date.getMonth() + 1);
  const jour = pad(date.getDate());
  const heures = pad(date.getHours());
  const minutes = pad(date.getMinutes());
  const secondes = pad(date.getSeconds());
  return `${annee}-${mois}-${jour} ${heures}:${minutes}:${secondes}`;
}
function formatDuration(totalMinutes) {
  const heures = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  let resultat = "";
  if (heures > 0) {
    resultat += heures + "h";
  }
  if (minutes > 0) {
    resultat += minutes + "min";
  } else if (totalMinutes === 0) {
    resultat = "0min";
  }
  return resultat;
}
function formatPrice(price, showCurrency = true) {
  const formatter = new Intl.NumberFormat("fr-FR", {
    style: "decimal",
    // Utilise le style décimal
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  });
  const formattedPrice = formatter.format(price);
  return formattedPrice + (showCurrency ? ` FCFA` : "");
}
export {
  formatPrice as a,
  formatDuration as b,
  calculateEndDate as c,
  formatDate as f,
  isDateInPast as i
};
