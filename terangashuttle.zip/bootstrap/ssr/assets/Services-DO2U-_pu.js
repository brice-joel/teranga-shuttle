import { jsxs, jsx } from "react/jsx-runtime";
import { U as UserLayout } from "./UserLayout-BtuPwiUA.js";
import { Head } from "@inertiajs/react";
import { Plane, Clock, Gem, Map } from "lucide-react";
import "react";
import "sonner";
const services = [
  {
    title: "Transferts Aéroport",
    desc: "Accueil personnalisé à l'AIBD (DSS) avec pancarte nominative, assistance bagages et transfert rapide.",
    icon: Plane
  },
  {
    title: "Mise à Disposition",
    desc: "Location horaire flexible pour vos rendez-vous d'affaires, shopping ou vos courses en ville sans contrainte.",
    icon: Clock
  },
  {
    title: "Événements VIP",
    desc: "Un transport d'exception pour vos mariages, sommets diplomatiques, conventions et soirées de gala.",
    icon: Gem
  },
  {
    title: "Tourisme de Luxe",
    desc: "Découvrez les joyaux du Sénégal (Lac Rose, Île de Gorée, Réserve de Bandia) dans un confort absolu.",
    icon: Map
  }
];
function Services() {
  return /* @__PURE__ */ jsxs(UserLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Nos Services - Teranga Shuttle" }),
    /* @__PURE__ */ jsxs("section", { className: "relative pt-40 pb-32 bg-slate-950 text-white text-center overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-[url('https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center opacity-20 mix-blend-luminosity" }),
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent" }),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 max-w-3xl mx-auto px-6", children: [
        /* @__PURE__ */ jsxs("h1", { className: "text-4xl md:text-6xl font-bold mb-6 tracking-tight", children: [
          "Nos Services",
          " ",
          /* @__PURE__ */ jsx("span", { className: "text-amber-500 italic font-serif", children: "Exclusifs" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-slate-400 text-lg font-light leading-relaxed", children: "L'excellence du transport privé au Sénégal, pensée sur-mesure pour s'adapter à chacune de vos exigences." })
      ] })
    ] }),
    /* @__PURE__ */ jsx("section", { className: "max-w-7xl mx-auto px-6 py-24 -mt-10 relative z-20", children: /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: services.map((s, i) => /* @__PURE__ */ jsxs(
      "div",
      {
        className: "flex flex-col sm:flex-row gap-6 p-8 md:p-10 rounded-[2rem] bg-white border border-slate-100 shadow-[0_10px_40px_-20px_rgba(0,0,0,0.05)] group hover:shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] hover:border-amber-500/20 transition-all duration-500 relative overflow-hidden",
        children: [
          /* @__PURE__ */ jsx("div", { className: "absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-amber-500/10 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" }),
          /* @__PURE__ */ jsx("div", { className: "w-16 h-16 shrink-0 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:bg-amber-500 group-hover:border-amber-500 group-hover:-translate-y-1 transition-all duration-300", children: /* @__PURE__ */ jsx(s.icon, { className: "w-7 h-7 text-amber-500 group-hover:text-slate-950 transition-colors" }) }),
          /* @__PURE__ */ jsxs("div", { className: "relative z-10", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold mb-3 text-slate-900 group-hover:text-amber-600 transition-colors", children: s.title }),
            /* @__PURE__ */ jsx("p", { className: "text-slate-500 leading-relaxed text-sm", children: s.desc })
          ] })
        ]
      },
      i
    )) }) })
  ] });
}
export {
  Services as default
};
