import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { T as TextInput, I as InputError } from "./TextInput-BpKdnAfj.js";
import { G as Guest } from "./GuestLayout-DJqyTTIZ.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { LogIn } from "lucide-react";
import "react";
import "sonner";
function Checkbox({
  className = "",
  ...props
}) {
  return /* @__PURE__ */ jsx(
    "input",
    {
      ...props,
      type: "checkbox",
      className: "rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500 " + className
    }
  );
}
function Login({
  status,
  canResetPassword
}) {
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: false
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("login"), {
      onFinish: () => reset("password")
    });
  };
  return /* @__PURE__ */ jsxs(Guest, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Connexion - Teranga Shuttle" }),
    /* @__PURE__ */ jsxs("div", { className: "mb-8 text-center", children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold text-slate-900 tracking-tight mb-2", children: [
        "Bon retour parmi",
        " ",
        /* @__PURE__ */ jsx("span", { className: "italic font-serif text-amber-500", children: "Nous" })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-slate-500 font-light", children: "Connectez-vous à votre espace client" })
    ] }),
    status && /* @__PURE__ */ jsx("div", { className: "mb-6 text-center text-sm font-bold text-emerald-600 bg-emerald-50 border border-emerald-100 p-4 rounded-2xl", children: status }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "email",
            className: "block text-xs uppercase tracking-widest font-bold text-slate-500 mb-2",
            children: "Adresse Email"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "email",
            type: "email",
            name: "email",
            value: data.email,
            className: "w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-slate-900 focus:ring-slate-900 shadow-sm transition-colors",
            autoComplete: "username",
            isFocused: true,
            onChange: (e) => setData("email", e.target.value),
            placeholder: ""
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.email, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "password",
            className: "block text-xs uppercase tracking-widest font-bold text-slate-500 mb-2",
            children: "Mot de passe"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "password",
            type: "password",
            name: "password",
            value: data.password,
            className: "w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-slate-900 focus:ring-slate-900 shadow-sm transition-colors",
            autoComplete: "current-password",
            onChange: (e) => setData("password", e.target.value),
            placeholder: "••••••••"
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.password, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs("label", { className: "flex items-center cursor-pointer group", children: [
          /* @__PURE__ */ jsx(
            Checkbox,
            {
              name: "remember",
              checked: data.remember,
              onChange: (e) => setData("remember", e.target.checked),
              className: "rounded text-slate-900 focus:ring-slate-900 border-slate-300"
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "ms-2 text-sm text-slate-500 group-hover:text-slate-800 transition-colors", children: "Se souvenir de moi" })
        ] }),
        canResetPassword && /* @__PURE__ */ jsx(
          Link,
          {
            href: route("password.request"),
            className: "text-sm font-semibold text-slate-500 hover:text-amber-600 transition-colors",
            children: "Mot de passe oublié ?"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "pt-2 space-y-4", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "submit",
            disabled: processing,
            className: "w-full flex items-center justify-center gap-2 bg-slate-950 text-white rounded-xl py-3.5 text-xs font-bold uppercase tracking-widest hover:bg-amber-500 hover:text-slate-950 transition-all shadow-lg shadow-slate-950/10 disabled:opacity-50 active:scale-95",
            children: processing ? /* @__PURE__ */ jsx("span", { className: "w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(LogIn, { className: "w-4 h-4" }),
              "Se connecter"
            ] })
          }
        ),
        /* @__PURE__ */ jsxs("p", { className: "text-center text-sm text-slate-500", children: [
          "Pas encore inscrit ?",
          " ",
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("register"),
              className: "font-bold text-slate-900 hover:text-amber-500 transition-colors",
              children: "Créer un compte"
            }
          )
        ] })
      ] })
    ] })
  ] });
}
export {
  Login as default
};
