import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@inertiajs/react";
function Success() {
  return /* @__PURE__ */ jsx("div", { className: "min-h-screen flex items-center justify-center bg-gray-50 p-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-xl w-full bg-white shadow rounded-lg p-8 text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-3xl font-semibold text-green-700 mb-4", children: "Paiement validé avec succès" }),
    /* @__PURE__ */ jsx("p", { className: "text-gray-600 mb-6", children: "Merci ! Votre paiement a été traité avec succès. Vous pouvez fermer cette page ou revenir à l'accueil." }),
    /* @__PURE__ */ jsx(
      Link,
      {
        href: route("home"),
        className: "px-6 py-3 bg-gray-900 text-white rounded hover:bg-gray-700 transition",
        children: "Retour à l'accueil"
      }
    )
  ] }) });
}
export {
  Success as default
};
