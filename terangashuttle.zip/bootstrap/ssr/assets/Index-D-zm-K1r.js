import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useMemo } from "react";
import { useForm, router } from "@inertiajs/react";
import { Plus, Search, Eye, Edit, Trash2, X, Loader2 } from "lucide-react";
import { a as formatPrice, b as formatDuration } from "./formatters-Dx77TuBc.js";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-CA9xhxbb.js";
import "sonner";
function Trips({ trips }) {
  const [search, setSearch] = useState("");
  const [activeModal, setActiveModal] = useState(null);
  const [selectedTrip, setSelectedTrip] = useState(null);
  const { data, setData, post, put, processing, errors, reset, clearErrors } = useForm({
    departure_city: "",
    arrival_city: "",
    fixed_price: "",
    estimated_duration_minutes: "",
    is_active: true
  });
  const filteredTrips = useMemo(() => {
    return trips.filter(
      (trip) => trip.departure_city.toLowerCase().includes(search.toLowerCase()) || trip.arrival_city.toLowerCase().includes(search.toLowerCase())
    );
  }, [trips, search]);
  const openModal = (type, trip = null) => {
    setActiveModal(type);
    setSelectedTrip(trip);
    clearErrors();
    if (type === "edit" && trip) {
      setData({
        departure_city: trip.departure_city,
        arrival_city: trip.arrival_city,
        fixed_price: trip.fixed_price.toString(),
        estimated_duration_minutes: trip.estimated_duration_minutes.toString(),
        is_active: trip.is_active
      });
    } else {
      reset();
    }
  };
  const closeModal = () => {
    setActiveModal(null);
    setSelectedTrip(null);
    reset();
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (activeModal === "create") {
      post(route("admin.trips.store"), { onSuccess: () => closeModal() });
    } else if (activeModal === "edit" && selectedTrip) {
      put(route("admin.trips.update", selectedTrip.id), {
        onSuccess: () => closeModal()
      });
    }
  };
  const handleDelete = () => {
    if (!selectedTrip) return;
    router.delete(route("admin.trips.destroy", selectedTrip.id), {
      onSuccess: () => closeModal()
    });
  };
  return /* @__PURE__ */ jsx(AuthenticatedLayout, { children: /* @__PURE__ */ jsxs("div", { className: "p-6 max-w-7xl mx-auto space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-gray-900", children: "Gestion des trajets" }),
      /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => openModal("create"),
          className: "inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors",
          children: [
            /* @__PURE__ */ jsx(Plus, { className: "w-4 h-4" }),
            " Ajouter un trajet"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "relative max-w-md", children: [
      /* @__PURE__ */ jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" }),
      /* @__PURE__ */ jsx(
        "input",
        {
          type: "text",
          placeholder: "Rechercher une ville de départ ou d'arrivée...",
          value: search,
          onChange: (e) => setSearch(e.target.value),
          className: "w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden", children: /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left border-collapse", children: [
      /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-600 uppercase tracking-wider", children: [
        /* @__PURE__ */ jsx("th", { className: "p-4", children: "Départ" }),
        /* @__PURE__ */ jsx("th", { className: "p-4", children: "Arrivée" }),
        /* @__PURE__ */ jsx("th", { className: "p-4", children: "Prix Fixe" }),
        /* @__PURE__ */ jsx("th", { className: "p-4", children: "Durée Estimée" }),
        /* @__PURE__ */ jsx("th", { className: "p-4", children: "Statut" }),
        /* @__PURE__ */ jsx("th", { className: "p-4 text-right", children: "Actions" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-gray-200 text-sm text-gray-700", children: filteredTrips.length > 0 ? filteredTrips.map((trip) => /* @__PURE__ */ jsxs(
        "tr",
        {
          className: "hover:bg-gray-50 transition-colors",
          children: [
            /* @__PURE__ */ jsx("td", { className: "p-4 font-medium text-gray-900", children: trip.departure_city }),
            /* @__PURE__ */ jsx("td", { className: "p-4 font-medium text-gray-900", children: trip.arrival_city }),
            /* @__PURE__ */ jsx("td", { className: "p-4", children: formatPrice(
              trip.fixed_price,
              false
            ) }),
            /* @__PURE__ */ jsx("td", { className: "p-4", children: formatDuration(
              trip.estimated_duration_minutes
            ) }),
            /* @__PURE__ */ jsx("td", { className: "p-4", children: /* @__PURE__ */ jsx(
              "span",
              {
                className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${trip.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`,
                children: trip.is_active ? "Actif" : "Inactif"
              }
            ) }),
            /* @__PURE__ */ jsxs("td", { className: "p-4 text-right space-x-2", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  onClick: () => openModal("view", trip),
                  className: "text-gray-500 hover:text-gray-700 p-1 inline-flex",
                  title: "Voir",
                  children: /* @__PURE__ */ jsx(Eye, { className: "w-4 h-4" })
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  onClick: () => openModal("edit", trip),
                  className: "text-blue-600 hover:text-blue-800 p-1 inline-flex",
                  title: "Modifier",
                  children: /* @__PURE__ */ jsx(Edit, { className: "w-4 h-4" })
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  onClick: () => openModal(
                    "delete",
                    trip
                  ),
                  className: "text-red-600 hover:text-red-800 p-1 inline-flex",
                  title: "Supprimer",
                  children: /* @__PURE__ */ jsx(Trash2, { className: "w-4 h-4" })
                }
              )
            ] })
          ]
        },
        trip.id
      )) : /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx(
        "td",
        {
          colSpan: 6,
          className: "p-8 text-center text-gray-500",
          children: "Aucun trajet trouvé."
        }
      ) }) })
    ] }) }) }),
    (activeModal === "create" || activeModal === "edit") && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 animate-fade-in", children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden flex flex-col", children: [
      /* @__PURE__ */ jsxs("div", { className: "px-6 py-4 border-b border-gray-200 flex items-center justify-between", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-lg font-bold text-gray-900", children: activeModal === "create" ? "Ajouter un nouveau trajet" : "Modifier le trajet" }),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: closeModal,
            className: "text-gray-400 hover:text-gray-600",
            children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxs(
        "form",
        {
          onSubmit: handleSubmit,
          className: "p-6 space-y-4",
          children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-medium text-gray-700 mb-1", children: "Départ" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.departure_city,
                  onChange: (e) => setData(
                    "departure_city",
                    e.target.value
                  ),
                  className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500",
                  required: true
                }
              ),
              errors.departure_city && /* @__PURE__ */ jsx("p", { className: "text-xs text-red-600 mt-1", children: errors.departure_city })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "block text-xs font-medium text-gray-700 mb-1", children: "Arrivée" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: data.arrival_city,
                  onChange: (e) => setData(
                    "arrival_city",
                    e.target.value
                  ),
                  className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500",
                  required: true
                }
              ),
              errors.arrival_city && /* @__PURE__ */ jsx("p", { className: "text-xs text-red-600 mt-1", children: errors.arrival_city })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-medium text-gray-700 mb-1", children: "Prix (FCFA)" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "number",
                    step: "0.01",
                    value: data.fixed_price,
                    onChange: (e) => setData(
                      "fixed_price",
                      e.target.value
                    ),
                    className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500",
                    required: true
                  }
                ),
                errors.fixed_price && /* @__PURE__ */ jsx("p", { className: "text-xs text-red-600 mt-1", children: errors.fixed_price })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("label", { className: "block text-xs font-medium text-gray-700 mb-1", children: "Durée (minutes)" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "number",
                    value: data.estimated_duration_minutes,
                    onChange: (e) => setData(
                      "estimated_duration_minutes",
                      e.target.value
                    ),
                    className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500",
                    required: true
                  }
                ),
                errors.estimated_duration_minutes && /* @__PURE__ */ jsx("p", { className: "text-xs text-red-600 mt-1", children: errors.estimated_duration_minutes })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 pt-2", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "checkbox",
                  id: "is_active",
                  checked: data.is_active,
                  onChange: (e) => setData(
                    "is_active",
                    e.target.checked
                  ),
                  className: "w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                }
              ),
              /* @__PURE__ */ jsx(
                "label",
                {
                  htmlFor: "is_active",
                  className: "text-sm font-medium text-gray-700 select-none",
                  children: "Trajet actif"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-3 pt-4 border-t border-gray-100", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: closeModal,
                  className: "px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50",
                  children: "Annuler"
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "submit",
                  disabled: processing,
                  className: "px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium flex items-center justify-center gap-2 min-w-[100px]",
                  children: processing ? /* @__PURE__ */ jsx(Loader2, { className: "w-4 h-4 animate-spin" }) : "Enregistrer"
                }
              )
            ] })
          ]
        }
      )
    ] }) }),
    activeModal === "view" && selectedTrip && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4", children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden", children: [
      /* @__PURE__ */ jsxs("div", { className: "px-6 py-4 border-b border-gray-200 flex items-center justify-between", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-lg font-bold text-gray-900", children: "Détails du trajet" }),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: closeModal,
            className: "text-gray-400 hover:text-gray-600",
            children: /* @__PURE__ */ jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "p-6 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-y-4 text-sm", children: [
          /* @__PURE__ */ jsx("span", { className: "text-gray-500 font-medium", children: "Ville départ :" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-900 font-semibold", children: selectedTrip.departure_city }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-500 font-medium", children: "Ville arrivée :" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-900 font-semibold", children: selectedTrip.arrival_city }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-500 font-medium", children: "Prix du Trajet :" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-900 font-semibold", children: formatPrice(
            selectedTrip.fixed_price,
            true
          ) }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-500 font-medium", children: "Durée estimée :" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-900 font-semibold", children: formatDuration(
            selectedTrip.estimated_duration_minutes
          ) }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-500 font-medium", children: "Statut :" }),
          /* @__PURE__ */ jsx("span", { children: /* @__PURE__ */ jsx(
            "span",
            {
              className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${selectedTrip.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`,
              children: selectedTrip.is_active ? "Actif" : "Inactif"
            }
          ) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-4 border-t border-gray-100", children: /* @__PURE__ */ jsx(
          "button",
          {
            onClick: closeModal,
            className: "px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-lg text-sm font-medium transition-colors",
            children: "Fermer"
          }
        ) })
      ] })
    ] }) }),
    activeModal === "delete" && selectedTrip && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4", children: /* @__PURE__ */ jsx("div", { className: "bg-white rounded-xl shadow-xl  max-w-sm overflow-hidden", children: /* @__PURE__ */ jsxs("div", { className: "p-6 text-center space-y-4", children: [
      /* @__PURE__ */ jsx("div", { className: "w-12 h-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto", children: /* @__PURE__ */ jsx(Trash2, { className: "w-6 h-6" }) }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h3", { className: "text-lg font-bold text-gray-900", children: "Confirmer la suppression" }),
        /* @__PURE__ */ jsxs("p", { className: "text-sm text-gray-500 mt-1", children: [
          "Êtes-vous sûr de vouloir supprimer le trajet de",
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-semibold", children: selectedTrip.departure_city }),
          " ",
          "à",
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-semibold", children: selectedTrip.arrival_city }),
          " ",
          "? Cette action est irréversible."
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-center gap-3 pt-2", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: closeModal,
            className: "px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50",
            children: "Annuler"
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: handleDelete,
            className: "px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-sm font-medium transition-colors",
            children: "Supprimer"
          }
        )
      ] })
    ] }) }) })
  ] }) });
}
export {
  Trips as default
};
