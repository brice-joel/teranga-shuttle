import { jsxs, jsx } from "react/jsx-runtime";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-CA9xhxbb.js";
import { a as formatPrice } from "./formatters-Dx77TuBc.js";
import { Head } from "@inertiajs/react";
import "react";
import "sonner";
import "lucide-react";
function Index({
  count_users,
  count_bookings,
  total_revenue,
  total_payments
}) {
  console.log(total_payments);
  return /* @__PURE__ */ jsxs(AuthenticatedLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Tableau de Bord" }),
    /* @__PURE__ */ jsxs("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-slate-900", children: "Bienvenue sur Teranga Shuttle" }),
      /* @__PURE__ */ jsx("p", { className: "text-slate-500", children: "Gérez vos réservations de Mercedes Classe V en toute simplicité." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 rounded-2xl border border-slate-200 shadow-sm", children: [
        /* @__PURE__ */ jsx("p", { className: "text-slate-500 text-sm font-medium", children: "Revenu total" }),
        /* @__PURE__ */ jsx("p", { className: "text-xl font-bold text-slate-900 mt-2", children: formatPrice(total_revenue) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 rounded-2xl border border-slate-200 shadow-sm", children: [
        /* @__PURE__ */ jsx("p", { className: "text-slate-500 text-sm font-medium", children: "Total réservations" }),
        /* @__PURE__ */ jsx("p", { className: "text-xl font-bold text-slate-900 mt-2", children: count_bookings })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 rounded-2xl border border-slate-200 shadow-sm", children: [
        /* @__PURE__ */ jsx("p", { className: "text-slate-500 text-sm font-medium", children: "Total transactions paiements" }),
        /* @__PURE__ */ jsx("p", { className: "text-xl font-bold text-slate-900 mt-2", children: formatPrice(total_payments) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white p-6 rounded-2xl border border-slate-200 shadow-sm", children: [
        /* @__PURE__ */ jsx("p", { className: "text-slate-500 text-sm font-medium", children: "Utilisateurs" }),
        /* @__PURE__ */ jsx("p", { className: "text-xl font-bold text-slate-900 mt-2", children: count_users })
      ] })
    ] })
  ] });
}
export {
  Index as default
};
