import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect, useMemo } from "react";
import { U as UserLayout } from "./UserLayout-BtuPwiUA.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { ShieldCheck, Search, ChevronRight, Calendar, Clock, Users, Briefcase, MessageSquare, Sparkles, CheckCircle } from "lucide-react";
import { C as CalendarModal } from "./CalendarModal-FZjeuHq3.js";
import { c as calculateEndDate, f as formatDate, b as formatDuration } from "./formatters-Dx77TuBc.js";
import { S as StepperInput } from "./StepperInput-D7wEdr1K.js";
import "sonner";
import "@fullcalendar/react";
import "@fullcalendar/timegrid";
import "@fullcalendar/interaction";
import "@fullcalendar/core/locales/fr";
function TripDetails({
  trip: initialTrip,
  bookingData,
  trips,
  bookings
}) {
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [currentTrip, setCurrentTrip] = useState(initialTrip);
  const [searchQuery, setSearchQuery] = useState(
    `${initialTrip.departure_city} → ${initialTrip.arrival_city}`
  );
  const [start_date, setStartDate] = useState(bookingData.start_time || "");
  const [end_date, setEndTime] = useState(
    calculateEndDate(
      bookingData.start_time,
      initialTrip.estimated_duration_minutes
    )
  );
  const { data, setData, post, processing, errors, transform } = useForm({
    trip_id: currentTrip.id,
    type: bookingData.type,
    start_time: bookingData.start_time || "",
    end_time: end_date || "",
    adults_count: bookingData.adults_count || 1,
    pickup_address: currentTrip.departure_city,
    dropoff_address: currentTrip.arrival_city,
    large_luggage_count: 0,
    small_luggage_count: 0,
    luggage_count: bookingData.luggage_count || 0,
    notes: "",
    total_amount: currentTrip.fixed_price || 0
  });
  useEffect(() => {
    const calculatedEnd = calculateEndDate(
      start_date,
      currentTrip.estimated_duration_minutes
    );
    setEndTime(calculatedEnd);
    setData("end_time", calculatedEnd);
  }, [start_date, currentTrip]);
  const filteredTrips = useMemo(() => {
    const currentLabel = `${currentTrip.departure_city} → ${currentTrip.arrival_city}`;
    if (!searchQuery || searchQuery === currentLabel) {
      return trips.slice(0, 4);
    }
    return trips.filter(
      (t) => `${t.departure_city} ${t.arrival_city}`.toLowerCase().includes(searchQuery.toLowerCase())
    ).slice(0, 6);
  }, [searchQuery, trips, currentTrip]);
  const handleSubmit = (e) => {
    e.preventDefault();
    transform((data2) => ({
      ...data2,
      luggage_count: data2.large_luggage_count + data2.small_luggage_count,
      notes: data2.notes + `

[Bagages : ${data2.large_luggage_count} grandes (23kg), ${data2.small_luggage_count} petites]`
    }));
    post(route("booking.store"));
  };
  const onSelectDateTime = (date) => {
    setData("start_time", date);
    setStartDate(date);
  };
  return /* @__PURE__ */ jsxs(UserLayout, { children: [
    /* @__PURE__ */ jsx(
      Head,
      {
        title: `Configurer mon trajet : ${currentTrip.departure_city} - ${currentTrip.arrival_city}`
      }
    ),
    /* @__PURE__ */ jsx("section", { className: "pt-28 pb-24 px-4 sm:px-6 max-w-6xl mx-auto", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8 items-start", children: [
      /* @__PURE__ */ jsxs("div", { className: "lg:col-span-7 space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-amber-50 text-amber-800 text-[11px] font-semibold border border-amber-200/40", children: [
            /* @__PURE__ */ jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-amber-500" }),
            "Personnalisation Privée"
          ] }),
          /* @__PURE__ */ jsxs("h1", { className: "text-2xl sm:text-3xl font-bold text-slate-950 tracking-tight", children: [
            "Configurez votre",
            " ",
            /* @__PURE__ */ jsx("span", { className: "text-amber-500", children: "transfert" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs sm:text-sm text-slate-500 max-w-lg", children: "Ajustez les détails de votre course exclusive. Votre chauffeur privé s'adaptera rigoureusement à vos exigences." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/60 shadow-sm space-y-3 relative", children: [
          /* @__PURE__ */ jsxs("label", { className: "text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsx(Search, { className: "w-3.5 h-3.5 text-slate-600" }),
            " ",
            "Itinéraire sélectionné"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                className: "w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 font-semibold text-sm text-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 focus:bg-white transition-all",
                value: searchQuery,
                onChange: (e) => {
                  setSearchQuery(e.target.value);
                  setShowSuggestions(true);
                },
                onFocus: () => setShowSuggestions(true)
              }
            ),
            showSuggestions && /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(
                "div",
                {
                  className: "fixed inset-0 z-40",
                  onClick: () => setShowSuggestions(false)
                }
              ),
              /* @__PURE__ */ jsx("div", { className: "absolute top-full left-0 w-full mt-2 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden z-50 divide-y divide-slate-100", children: filteredTrips.map((t) => /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  className: "w-full px-4 py-3 text-left hover:bg-slate-50 flex items-center justify-between group transition-colors text-xs",
                  onClick: () => {
                    setCurrentTrip(t);
                    setData((prev) => ({
                      ...prev,
                      trip_id: t.id,
                      total_amount: t.fixed_price,
                      pickup_address: t.departure_city,
                      dropoff_address: t.arrival_city
                    }));
                    setSearchQuery(
                      `${t.departure_city} → ${t.arrival_city}`
                    );
                    setShowSuggestions(
                      false
                    );
                  },
                  children: [
                    /* @__PURE__ */ jsxs("span", { className: "font-semibold text-slate-800", children: [
                      t.departure_city,
                      " ",
                      "→ ",
                      t.arrival_city
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "text-amber-600 font-bold flex items-center gap-1", children: [
                      Number(
                        t.fixed_price
                      ).toLocaleString(),
                      " ",
                      "CFA",
                      /* @__PURE__ */ jsx(ChevronRight, { className: "w-3.5 h-3.5 text-slate-300 group-hover:text-amber-500 group-hover:translate-x-0.5 transition-all" })
                    ] })
                  ]
                },
                t.id
              )) })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between gap-3", children: [
            /* @__PURE__ */ jsxs("label", { className: "text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx(Calendar, { className: "w-3.5 h-3.5 text-amber-500" }),
              " ",
              "Prise en charge"
            ] }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => setIsCalendarOpen(true),
                className: "w-full py-2.5 px-4 bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 rounded-xl font-semibold text-xs flex justify-between items-center shadow-sm transition-colors",
                children: [
                  /* @__PURE__ */ jsx("span", { children: data.start_time ? formatDate(data.start_time) : "Planifier la date & heure" }),
                  /* @__PURE__ */ jsx(Clock, { className: "w-4 h-4 text-slate-600" })
                ]
              }
            ),
            errors.start_time && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-red-500 font-medium", children: errors.start_time })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between gap-3", children: [
            /* @__PURE__ */ jsx("label", { className: "text-[11px] font-bold text-slate-600 uppercase tracking-wider", children: "Capacité requise" }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex-1 bg-slate-50 border border-slate-100 rounded-xl p-2.5 flex flex-col gap-2", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx(Users, { className: "w-4 h-4 text-slate-600 shrink-0" }),
                  /* @__PURE__ */ jsx("span", { className: "block text-[9px] font-bold uppercase text-slate-600 leading-none", children: "Passagers" })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "flex justify-center mt-1", children: /* @__PURE__ */ jsx(
                  StepperInput,
                  {
                    value: data.adults_count,
                    onChange: (v) => setData("adults_count", v),
                    min: 1,
                    max: 7
                  }
                ) })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex-1 bg-slate-50 border border-slate-100 rounded-xl p-3 flex flex-col gap-3", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx(Briefcase, { className: "w-4 h-4 text-slate-600 shrink-0" }),
                  /* @__PURE__ */ jsx("span", { className: "block text-[9px] font-bold uppercase text-slate-600 leading-none", children: "Bagages" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-[10px] text-slate-600 font-medium", children: "Grand (23kg)" }),
                    /* @__PURE__ */ jsx(
                      StepperInput,
                      {
                        value: data.large_luggage_count,
                        onChange: (v) => setData("large_luggage_count", v),
                        min: 0,
                        max: 5
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-[10px] text-slate-600 font-medium", children: "Petit" }),
                    /* @__PURE__ */ jsx(
                      StepperInput,
                      {
                        value: data.small_luggage_count,
                        onChange: (v) => setData("small_luggage_count", v),
                        min: 0,
                        max: 4
                      }
                    )
                  ] })
                ] })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/60 shadow-sm space-y-3", children: [
          /* @__PURE__ */ jsxs("label", { className: "text-[11px] font-bold text-slate-600 capitalize tracking-wider flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsx(MessageSquare, { className: "w-3.5 h-3.5 text-slate-600" }),
            " ",
            "Consignes et exigences durant le transport (Optionnel)"
          ] }),
          /* @__PURE__ */ jsx(
            "textarea",
            {
              placeholder: "",
              className: "w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 focus:outline-none focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 focus:bg-white text-xs text-slate-800 min-h-[90px] resize-none transition-all placeholder:text-slate-600",
              value: data.notes,
              onChange: (e) => setData("notes", e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "lg:col-span-5 lg:sticky lg:top-28", children: /* @__PURE__ */ jsxs("div", { className: "bg-slate-950 rounded-2xl p-6 text-white shadow-xl shadow-slate-950/20 border border-slate-800 relative overflow-hidden", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute -right-16 -top-16 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" }),
        /* @__PURE__ */ jsxs("h3", { className: "text-amber-500 font-bold uppercase text-[11px] tracking-wider flex items-center gap-1.5 mb-6 border-b border-white/5 pb-4", children: [
          /* @__PURE__ */ jsx(Sparkles, { className: "w-3.5 h-3.5" }),
          "Récapitulatif de la course"
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4 text-xs mb-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-white/5 rounded-xl p-3.5 border border-white/5 space-y-3", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("p", { className: "text-[9px] font-bold text-slate-500 uppercase tracking-wider", children: "Itinéraire" }),
              /* @__PURE__ */ jsxs("p", { className: "font-semibold text-sm text-slate-100 mt-0.5", children: [
                currentTrip.departure_city,
                " →",
                " ",
                currentTrip.arrival_city
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-white/5", children: [
              /* @__PURE__ */ jsxs("span", { children: [
                "Durée estimée :",
                " ",
                formatDuration(
                  currentTrip.estimated_duration_minutes
                )
              ] }),
              /* @__PURE__ */ jsx("span", { className: "text-amber-500 font-medium", children: "Mercedez Benz class V220d" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-white/5 rounded-xl p-3 border border-white/5", children: [
              /* @__PURE__ */ jsx("p", { className: "text-[9px] font-bold text-slate-500 uppercase tracking-wider", children: "Départ planifié" }),
              /* @__PURE__ */ jsx("p", { className: "font-semibold text-slate-200 mt-0.5 ", children: start_date ? formatDate(start_date) : "Non défini" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-white/5 rounded-xl p-3 border border-white/5", children: [
              /* @__PURE__ */ jsx("p", { className: "text-[9px] font-bold text-slate-400 uppercase tracking-wider", children: "Arrivée estimée" }),
              /* @__PURE__ */ jsx("p", { className: "font-semibold text-slate-400 mt-0.5 ", children: end_date && start_date ? formatDate(end_date) : "En attente" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-white/5 rounded-xl p-3 border border-white/5 flex items-center justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-400 text-[11px]", children: "Passager(s)" }),
              /* @__PURE__ */ jsx("span", { className: "font-bold text-slate-100", children: data.adults_count })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-white/5 rounded-xl p-3 border border-white/5 flex items-center justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-400 text-[11px]", children: "Bagage(s)" }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-end", children: [
                /* @__PURE__ */ jsx("span", { className: "font-bold text-slate-100", children: data.large_luggage_count + data.small_luggage_count }),
                (data.large_luggage_count > 0 || data.small_luggage_count > 0) && /* @__PURE__ */ jsxs("span", { className: "text-[9px] text-slate-400 mt-0.5 text-right", children: [
                  data.large_luggage_count,
                  " grand(s), ",
                  data.small_luggage_count,
                  " petit(s)"
                ] })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mb-6 bg-white/5 p-4 rounded-xl border border-white/5", children: [
          /* @__PURE__ */ jsx("p", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1", children: "Tarif Forfaitaire Fixe" }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-baseline gap-1", children: [
            /* @__PURE__ */ jsx("span", { className: "text-2xl font-bold text-amber-500 tracking-tight", children: Number(
              currentTrip.fixed_price
            ).toLocaleString() }),
            /* @__PURE__ */ jsx("span", { className: "text-xs font-semibold text-amber-500", children: "FCFA" })
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "flex text-[10px] text-slate-400 mt-1.5 italic", children: [
            /* @__PURE__ */ jsx(CheckCircle, { className: " w-3.5 h-3.5 mr-2 text-amber-500 shrink-0" }),
            " ",
            /* @__PURE__ */ jsx("span", { className: "text-amber-500", children: "Carburant et frais de route à la charge du client" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: handleSubmit,
              disabled: processing || !data.start_time,
              className: "w-full bg-amber-500 text-slate-950 py-3 rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-amber-400 active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 disabled:opacity-20 disabled:cursor-not-allowed group",
              children: [
                processing ? /* @__PURE__ */ jsx("span", { className: "w-4 h-4 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" }) : /* @__PURE__ */ jsx("span", { children: "Confirmer la demande" }),
                /* @__PURE__ */ jsx(ChevronRight, { className: "w-4 h-4 group-hover:translate-x-0.5 transition-transform" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-2 text-[10px] text-slate-500 uppercase font-bold tracking-widest my-2", children: [
            /* @__PURE__ */ jsx("span", { className: "h-px bg-slate-800 flex-1" }),
            /* @__PURE__ */ jsx("span", { children: "ou" }),
            /* @__PURE__ */ jsx("span", { className: "h-px bg-slate-800 flex-1" })
          ] }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("devis.index", { ...data }),
              type: "button",
              as: "button",
              className: "w-full bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white py-3 rounded-xl font-bold text-xs uppercase tracking-wider active:scale-[0.99] transition-all flex items-center justify-center gap-2 group",
              children: [
                /* @__PURE__ */ jsx("span", { children: "Demander un devis personnalisé" }),
                /* @__PURE__ */ jsx(ChevronRight, { className: "w-4 h-4 text-slate-500 group-hover:text-white group-hover:translate-x-0.5 transition-transform" })
              ]
            }
          )
        ] })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsx(
      CalendarModal,
      {
        isOpen: isCalendarOpen,
        onClose: () => setIsCalendarOpen(false),
        onSelect: (date) => onSelectDateTime(date),
        bookings
      }
    )
  ] });
}
export {
  TripDetails as default
};
