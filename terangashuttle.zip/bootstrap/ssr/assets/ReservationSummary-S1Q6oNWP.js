import { jsxs, jsx } from "react/jsx-runtime";
import { useForm } from "@inertiajs/react";
function ReservationSummary() {
  let vehicle = {
    id: 1,
    name: "Mercedes Classe C",
    daily_rate: 3333.33
  };
  const { post, processing } = useForm({
    vehicle_id: vehicle.id,
    vehicle_name: vehicle.name,
    total_price: vehicle.daily_rate * 3
    // Exemple pour 3 jours
  });
  const handlePayment = (e) => {
    e.preventDefault();
    post(route("payment.checkout"));
  };
  return /* @__PURE__ */ jsxs("div", { className: "p-6 bg-white rounded-lg shadow", children: [
    /* @__PURE__ */ jsx("h2", { className: "text-xl font-bold", children: vehicle.name }),
    /* @__PURE__ */ jsxs("p", { className: "mt-2 text-gray-600", children: [
      "Total : ",
      vehicle.daily_rate * 3,
      " €"
    ] }),
    /* @__PURE__ */ jsx(
      "button",
      {
        onClick: handlePayment,
        disabled: processing,
        className: "mt-4 w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 disabled:opacity-50",
        children: processing ? "Chargement..." : "Payer par Carte"
      }
    )
  ] });
}
export {
  ReservationSummary as default
};
