import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { T as TextInput, I as InputError } from "./TextInput-BpKdnAfj.js";
import { G as Guest } from "./GuestLayout-DJqyTTIZ.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { UserPlus } from "lucide-react";
import "react";
import "sonner";
function Register() {
  const { data, setData, post, processing, errors, reset } = useForm({
    name: "",
    email: "",
    password: "",
    password_confirmation: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("register"), {
      onFinish: () => reset("password", "password_confirmation")
    });
  };
  return /* @__PURE__ */ jsxs(Guest, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Inscription - Teranga Shuttle" }),
    /* @__PURE__ */ jsxs("div", { className: "mb-8 text-center", children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold text-slate-900 tracking-tight mb-2", children: [
        "Créer un",
        " ",
        /* @__PURE__ */ jsx("span", { className: "italic font-serif text-amber-500", children: "Compte" })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-slate-500 font-light", children: "Rejoignez Teranga Shuttle pour réserver vos trajets" })
    ] }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "name",
            className: "block text-xs uppercase tracking-widest font-bold text-slate-500 mb-2",
            children: "Nom complet"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "name",
            name: "name",
            value: data.name,
            className: "w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-slate-900 focus:ring-slate-900 shadow-sm transition-colors",
            autoComplete: "name",
            isFocused: true,
            onChange: (e) => setData("name", e.target.value),
            placeholder: "Jean Dupont",
            required: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.name, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "email",
            className: "block text-xs uppercase tracking-widest font-bold text-slate-500 mb-2",
            children: "Adresse Email"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "email",
            type: "email",
            name: "email",
            value: data.email,
            className: "w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-slate-900 focus:ring-slate-900 shadow-sm transition-colors",
            autoComplete: "username",
            onChange: (e) => setData("email", e.target.value),
            placeholder: "jean.dupont@exemple.com",
            required: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.email, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "password",
            className: "block text-xs uppercase tracking-widest font-bold text-slate-500 mb-2",
            children: "Mot de passe"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "password",
            type: "password",
            name: "password",
            value: data.password,
            className: "w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-slate-900 focus:ring-slate-900 shadow-sm transition-colors",
            autoComplete: "new-password",
            onChange: (e) => setData("password", e.target.value),
            placeholder: "••••••••",
            required: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.password, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "password_confirmation",
            className: "block text-xs uppercase tracking-widest font-bold text-slate-500 mb-2",
            children: "Confirmer le mot de passe"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "password_confirmation",
            type: "password",
            name: "password_confirmation",
            value: data.password_confirmation,
            className: "w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-slate-900 focus:ring-slate-900 shadow-sm transition-colors",
            autoComplete: "new-password",
            onChange: (e) => setData("password_confirmation", e.target.value),
            placeholder: "••••••••",
            required: true
          }
        ),
        /* @__PURE__ */ jsx(
          InputError,
          {
            message: errors.password_confirmation,
            className: "mt-2"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "pt-4 space-y-4", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "submit",
            disabled: processing,
            className: "w-full flex items-center justify-center gap-2 bg-slate-950 text-white rounded-xl py-3.5 text-xs font-bold uppercase tracking-widest hover:bg-amber-500 hover:text-slate-950 transition-all shadow-lg shadow-slate-950/10 disabled:opacity-50 active:scale-95",
            children: processing ? /* @__PURE__ */ jsx("span", { className: "w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(UserPlus, { className: "w-4 h-4" }),
              "S'inscrire"
            ] })
          }
        ),
        /* @__PURE__ */ jsxs("p", { className: "text-center text-sm text-slate-500", children: [
          "Vous avez déjà un compte ?",
          " ",
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("login"),
              className: "font-bold text-slate-900 hover:text-amber-500 transition-colors",
              children: "Se connecter"
            }
          )
        ] })
      ] })
    ] })
  ] });
}
export {
  Register as default
};
