import { jsxs, jsx } from "react/jsx-runtime";
import { useForm, router, Head } from "@inertiajs/react";
import { MapPin, Search, ChevronRight, Calendar, Clock, ArrowRight, Award, ChevronDown, Sparkles, Star, ShieldCheck } from "lucide-react";
import { useState, useMemo } from "react";
import { C as CalendarModal } from "./CalendarModal-FZjeuHq3.js";
import { f as formatDate } from "./formatters-Dx77TuBc.js";
import { toast } from "sonner";
import { U as UserLayout } from "./UserLayout-BtuPwiUA.js";
import "@fullcalendar/react";
import "@fullcalendar/timegrid";
import "@fullcalendar/interaction";
import "@fullcalendar/core/locales/fr";
function BookingEngine({ trips, bookings = [] }) {
  const [bookingType, setBookingType] = useState(
    "course"
  );
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const { data, setData } = useForm({
    trip_id: "",
    type: "course_fixed",
    pickup_address: "",
    start_time: "",
    duration_hours: 2,
    adults_count: 1,
    luggage_count: 0
  });
  const filteredTrips = useMemo(() => {
    if (!searchQuery) return trips.slice(0, 5);
    return trips.filter(
      (t) => `${t.departure_city} ${t.arrival_city}`.toLowerCase().includes(searchQuery.toLowerCase())
    ).slice(0, 8);
  }, [searchQuery, trips]);
  const handleSeeDetails = (e) => {
    e.preventDefault();
    if (!data.start_time) {
      toast.error("Veuillez sélectionner une date et heure.");
      return;
    }
    const routeName = bookingType === "course" ? "booking.trip.details" : "booking.event.details";
    router.get(route(routeName), { ...data });
  };
  return /* @__PURE__ */ jsxs("div", { className: "bg-white/80 backdrop-blur-2xl border border-white shadow-[0_30px_60px_-15px_rgba(0,0,0,0.12)] rounded-[2rem] md:rounded-[3rem] p-6 md:p-10 w-full max-w-5xl mx-auto -mt-24 relative z-40", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex p-1.5 bg-slate-100/80 rounded-2xl w-full md:w-fit mb-8 mx-auto md:mx-0 border border-slate-200/50", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => {
            setBookingType("course");
            setData("type", "course_fixed");
          },
          className: `flex-1 md:flex-none px-8 py-3 rounded-xl text-xs md:text-sm font-black tracking-wider uppercase transition-all duration-300 ${bookingType === "course" ? "bg-white text-slate-900 shadow-[0_2px_10px_-2px_rgba(0,0,0,0.1)]" : "text-slate-400 hover:text-slate-600"}`,
          children: "Transfert"
        }
      ),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => {
            setBookingType("event");
            setData("type", "event_hourly");
          },
          className: `flex-1 md:flex-none px-8 py-3 rounded-xl text-xs md:text-sm font-black tracking-wider uppercase transition-all duration-300 ${bookingType === "event" ? "bg-white text-slate-900 shadow-[0_2px_10px_-2px_rgba(0,0,0,0.1)]" : "text-slate-400 hover:text-slate-600"}`,
          children: "Mise à disposition"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs(
      "form",
      {
        onSubmit: handleSeeDetails,
        className: "grid grid-cols-1 md:grid-cols-12 gap-5 items-end",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "md:col-span-5 relative group", children: [
            /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2.5 pl-2", children: [
              /* @__PURE__ */ jsx(MapPin, { className: "w-3.5 h-3.5 text-amber-500" }),
              bookingType === "course" ? "Votre Itinéraire" : "Prise en charge"
            ] }),
            bookingType === "course" ? /* @__PURE__ */ jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsx(Search, { className: "absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 transition-colors group-focus-within:text-amber-500" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  placeholder: "Où allez-vous ? (ex: Dakar, AIBD...)",
                  className: "w-full h-[60px] bg-slate-50/50 border border-slate-200 rounded-2xl py-4 pl-14 pr-4 focus:bg-white focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 font-bold text-slate-900 text-sm transition-all placeholder:text-slate-400 placeholder:font-medium",
                  value: searchQuery,
                  onChange: (e) => {
                    setSearchQuery(e.target.value);
                    setShowSuggestions(true);
                  },
                  onFocus: () => setShowSuggestions(true),
                  onBlur: () => setTimeout(
                    () => setShowSuggestions(false),
                    200
                  ),
                  required: true
                }
              ),
              /* @__PURE__ */ jsxs(
                "div",
                {
                  className: `absolute top-[calc(100%+8px)] left-0 w-full bg-white border border-slate-100 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.1)] rounded-2xl overflow-hidden z-[60] py-2 transition-all duration-300 origin-top ${showSuggestions ? "opacity-100 scale-100" : "opacity-0 scale-95 pointer-events-none"}`,
                  children: [
                    filteredTrips.map((trip) => /* @__PURE__ */ jsxs(
                      "button",
                      {
                        type: "button",
                        className: "w-full px-5 py-3.5 text-left hover:bg-slate-50 flex items-center justify-between group/item transition-colors",
                        onClick: () => {
                          setData("trip_id", trip.id);
                          setSearchQuery(
                            `${trip.departure_city} → ${trip.arrival_city}`
                          );
                          setShowSuggestions(false);
                        },
                        children: [
                          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-0.5", children: [
                            /* @__PURE__ */ jsxs("span", { className: "font-bold text-sm text-slate-900 group-hover/item:text-amber-600 transition-colors", children: [
                              trip.departure_city,
                              " →",
                              " ",
                              trip.arrival_city
                            ] }),
                            /* @__PURE__ */ jsxs("span", { className: "text-[11px] font-medium text-slate-400 uppercase tracking-wider", children: [
                              "Prix fixe : ",
                              trip.fixed_price,
                              " ",
                              "FCFA"
                            ] })
                          ] }),
                          /* @__PURE__ */ jsx(ChevronRight, { className: "w-4 h-4 text-slate-300 group-hover/item:text-amber-500 group-hover/item:translate-x-1 transition-all" })
                        ]
                      },
                      trip.id
                    )),
                    filteredTrips.length === 0 && /* @__PURE__ */ jsx("div", { className: "px-5 py-4 text-sm text-slate-500 text-center italic", children: "Aucun trajet trouvé." })
                  ]
                }
              )
            ] }) : /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                placeholder: "Hôtel, Adresse, Ville...",
                className: "w-full h-[60px] bg-slate-50/50 border border-slate-200 rounded-2xl py-4 px-6 focus:bg-white focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 font-bold text-slate-900 text-sm transition-all placeholder:text-slate-400 placeholder:font-medium",
                onChange: (e) => setData("pickup_address", e.target.value),
                required: true
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "md:col-span-4 relative group", children: [
            /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2.5 pl-2", children: [
              /* @__PURE__ */ jsx(Calendar, { className: "w-3.5 h-3.5 text-amber-500" }),
              " Date & Heure"
            ] }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => setIsCalendarOpen(true),
                className: "w-full h-[60px] bg-slate-50/50 border border-slate-200 rounded-2xl py-4 px-6 text-left focus:bg-white focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 flex items-center justify-between group transition-all",
                children: [
                  /* @__PURE__ */ jsx(
                    "span",
                    {
                      className: `text-sm ${data.start_time ? "font-bold text-slate-900" : "font-medium text-slate-400"}`,
                      children: data.start_time ? formatDate(data.start_time) : "Quand partez-vous ?"
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    Clock,
                    {
                      className: `w-5 h-5 transition-colors ${data.start_time ? "text-amber-500" : "text-slate-400 group-focus-within:text-amber-500"}`
                    }
                  )
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { className: "md:col-span-3", children: /* @__PURE__ */ jsxs(
            "button",
            {
              type: "submit",
              className: "w-full h-[60px] bg-slate-950 text-white rounded-2xl font-black uppercase text-[11px] tracking-[0.15em] hover:bg-amber-500 hover:text-slate-950 transition-all duration-300 shadow-xl shadow-slate-950/10 hover:shadow-amber-500/25 flex items-center justify-center gap-3 group active:scale-95",
              children: [
                "Calculer le prix",
                /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4 group-hover:translate-x-1.5 transition-transform" })
              ]
            }
          ) })
        ]
      }
    ),
    /* @__PURE__ */ jsx(
      CalendarModal,
      {
        isOpen: isCalendarOpen,
        onClose: () => setIsCalendarOpen(false),
        onSelect: (date) => setData("start_time", date),
        bookings
      }
    )
  ] });
}
function Home({ trips, bookings }) {
  return /* @__PURE__ */ jsx(UserLayout, { transparent: true, children: /* @__PURE__ */ jsxs("div", { className: "bg-white", children: [
    /* @__PURE__ */ jsx(Head, { title: "Teranga Shuttle - L'Élégance du Transport VIP" }),
    /* @__PURE__ */ jsxs("section", { className: "relative h-[90vh] min-h-[600px] flex items-center justify-center overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-900/50 to-slate-950/90 z-10" }),
      /* @__PURE__ */ jsx(
        "img",
        {
          src: "https://images.unsplash.com/photo-1554672408-730436b60dde?auto=format&fit=crop&q=80&w=2000",
          className: "absolute inset-0 w-full h-full object-cover scale-105 animate-[slow-zoom_20s_ease-in-out_infinite_alternate]",
          alt: "Mercedes Classe V VIP"
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "relative z-20 text-center px-4 max-w-5xl mt-16 md:mt-0", children: [
        /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-2.5 bg-amber-500/10 backdrop-blur-md border border-amber-500/20 text-amber-400 px-5 py-2.5 rounded-full mb-8 shadow-[0_0_30px_-5px_rgba(245,158,11,0.3)]", children: [
          /* @__PURE__ */ jsx(Award, { className: "w-4 h-4" }),
          /* @__PURE__ */ jsx("span", { className: "text-[10px] sm:text-xs font-bold uppercase tracking-[0.2em]", children: "L'Excellence du Transport au Sénégal" })
        ] }),
        /* @__PURE__ */ jsxs("h1", { className: "text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-white mb-6 leading-[1.05] tracking-tight", children: [
          "L'Élégance de vos ",
          /* @__PURE__ */ jsx("br", { className: "hidden md:block" }),
          "déplacements",
          " ",
          /* @__PURE__ */ jsx("span", { className: "text-amber-500 italic font-serif font-medium pr-2", children: "privés." })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-base sm:text-lg md:text-xl text-slate-300 max-w-2xl mx-auto mb-12 leading-relaxed font-light", children: "Profitez du confort inégalé d'une Mercedes Classe V avec chauffeur privé pour vos transferts, mariages et événements professionnels." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "absolute bottom-32 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 opacity-60", children: [
        /* @__PURE__ */ jsx("span", { className: "text-[10px] font-bold text-white uppercase tracking-widest", children: "Réserver" }),
        /* @__PURE__ */ jsx(ChevronDown, { className: "w-5 h-5 text-white animate-bounce" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("section", { className: "px-4 sm:px-6 relative z-30 pb-24", children: /* @__PURE__ */ jsx(BookingEngine, { trips, bookings }) }),
    /* @__PURE__ */ jsxs("section", { className: "max-w-7xl mx-auto px-6 py-24 border-t border-slate-100", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-20", children: [
        /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center justify-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsx(Sparkles, { className: "w-4 h-4 text-amber-500" }),
          /* @__PURE__ */ jsx("span", { className: "text-xs font-black uppercase tracking-widest text-slate-400", children: "Pourquoi nous choisir" })
        ] }),
        /* @__PURE__ */ jsxs("h2", { className: "text-3xl md:text-5xl font-bold text-slate-900 mb-6 tracking-tight", children: [
          "Un service sans",
          " ",
          /* @__PURE__ */ jsx("span", { className: "italic font-serif text-slate-500 font-medium", children: "compromis" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "w-16 h-1 bg-amber-500 mx-auto rounded-full" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12", children: [
        {
          title: "Confort Premium",
          icon: Star,
          desc: "Mercedes Classe V 220d : 8 places, intérieur cuir étendu, sièges massants et climatisation tri-zone personnalisable."
        },
        {
          title: "Sécurité Maximale",
          icon: ShieldCheck,
          desc: "Chauffeurs professionnels formés à la conduite défensive. Véhicules rigoureusement entretenus selon les standards allemands."
        },
        {
          title: "Discrétion Totale",
          icon: Award,
          desc: "Service sur-mesure et confidentialité absolue pour nos personnalités, délégations diplomatiques et événements privés."
        }
      ].map((feature, i) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: "group relative p-10 rounded-[2rem] bg-slate-50 border border-slate-100 hover:bg-white hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)] hover:border-amber-500/20 transition-all duration-500",
          children: [
            /* @__PURE__ */ jsx("div", { className: "absolute top-0 left-10 w-20 h-1 bg-gradient-to-r from-amber-500 to-amber-300 rounded-b-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" }),
            /* @__PURE__ */ jsx("div", { className: "w-16 h-16 rounded-2xl bg-white shadow-sm border border-slate-100 flex items-center justify-center mb-8 group-hover:-translate-y-2 transition-transform duration-500", children: /* @__PURE__ */ jsx(feature.icon, { className: "w-8 h-8 text-amber-500" }) }),
            /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-slate-900 mb-4 tracking-tight", children: feature.title }),
            /* @__PURE__ */ jsx("p", { className: "text-slate-500 leading-relaxed text-sm", children: feature.desc })
          ]
        },
        i
      )) })
    ] })
  ] }) });
}
export {
  Home as default
};
