import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useMemo } from "react";
import { U as UserLayout } from "./UserLayout-BtuPwiUA.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { Star, MapPin, Calendar, Clock, Users, Briefcase, MessageSquare, CheckCircle, ChevronRight } from "lucide-react";
import dayjs from "dayjs";
import { f as formatDate } from "./formatters-Dx77TuBc.js";
import { C as CalendarModal } from "./CalendarModal-FZjeuHq3.js";
import { S as StepperInput } from "./StepperInput-D7wEdr1K.js";
import "sonner";
import "@fullcalendar/react";
import "@fullcalendar/timegrid";
import "@fullcalendar/interaction";
import "@fullcalendar/core/locales/fr";
function EventDetails({
  bookingData,
  pricing,
  bookings
}) {
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const { data, setData, post, processing, transform } = useForm({
    type: "event_hourly",
    pickup_address: bookingData.pickup_address || "",
    start_time: bookingData.start_time || "",
    duration_hours: bookingData.duration_hours || 2,
    adults_count: bookingData.adults_count || 1,
    large_luggage_count: 0,
    small_luggage_count: 0,
    luggage_count: bookingData.luggage_count || 0,
    notes: ""
  });
  const endTime = useMemo(() => {
    if (!data.start_time) return null;
    return dayjs(data.start_time).add(data.duration_hours, "hour").format();
  }, [data.start_time, data.duration_hours]);
  const totalPrice = calculerPrixReservation(
    data.duration_hours,
    data.start_time,
    pricing.hourly_rate
  );
  const handleSubmit = (e) => {
    e.preventDefault();
    transform((data2) => ({
      ...data2,
      luggage_count: data2.large_luggage_count + data2.small_luggage_count,
      notes: data2.notes + `

[Bagages : ${data2.large_luggage_count} grandes (23kg), ${data2.small_luggage_count} petites]`
    }));
    post(route("bookings.store"));
  };
  const onSelectDateTime = (date) => {
    setData("start_time", date);
  };
  return /* @__PURE__ */ jsxs(UserLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Location vehicule - Teranga Shuttle" }),
    /* @__PURE__ */ jsx("section", { className: "pt-28 pb-16 px-4 sm:px-6 max-w-6xl mx-auto", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8 items-start", children: [
      /* @__PURE__ */ jsxs("div", { className: "lg:col-span-7 space-y-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 text-[10px] font-black uppercase tracking-widest", children: [
            /* @__PURE__ */ jsx(Star, { className: "w-3 h-3 fill-amber-600 text-amber-600" }),
            " ",
            "Service Conciergerie VIP"
          ] }),
          /* @__PURE__ */ jsxs("h1", { className: "text-2xl sm:text-3xl font-black uppercase italic tracking-tight text-slate-950", children: [
            "Location",
            " ",
            /* @__PURE__ */ jsx("span", { className: "text-amber-500", children: "Horaire" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between gap-2", children: [
            /* @__PURE__ */ jsxs("label", { className: "text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx(MapPin, { className: "w-3.5 h-3.5 text-amber-500" }),
              " ",
              "Prise en charge"
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                placeholder: "Ex: Aéroport AIBD, Hôtel Terrou-Bi...",
                value: data.pickup_address,
                onChange: (e) => setData(
                  "pickup_address",
                  e.target.value
                ),
                className: "w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 font-semibold text-xs text-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 focus:bg-white transition-all"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between gap-2", children: [
            /* @__PURE__ */ jsxs("label", { className: "text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx(Calendar, { className: "w-3.5 h-3.5 text-amber-500" }),
              " ",
              "Date & Heure de départ"
            ] }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => setIsCalendarOpen(true),
                className: "w-full py-2.5 px-4 bg-slate-50 hover:bg-slate-100/70 text-slate-900 border border-slate-200 rounded-xl font-semibold text-xs flex justify-between items-center transition-all group",
                children: [
                  /* @__PURE__ */ jsx(
                    "span",
                    {
                      className: data.start_time ? "text-slate-900 font-semibold" : "text-slate-400 font-medium",
                      children: data.start_time ? formatDate(data.start_time) : "Planifier le départ"
                    }
                  ),
                  /* @__PURE__ */ jsx(Clock, { className: "w-4 h-4 text-slate-500 group-hover:text-amber-500 transition-colors" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/60 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-end", children: [
            /* @__PURE__ */ jsx("label", { className: "text-[11px] font-bold uppercase text-slate-600 tracking-wider", children: "Durée souhaitée" }),
            /* @__PURE__ */ jsxs("div", { className: "text-2xl font-black italic text-slate-900", children: [
              data.duration_hours,
              " ",
              /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-amber-500 uppercase not-italic", children: "Heures" })
            ] })
          ] }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "range",
              min: "1",
              max: "24",
              step: "1",
              value: data.duration_hours,
              onChange: (e) => setData(
                "duration_hours",
                parseInt(e.target.value)
              ),
              className: "w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-amber-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between space-y-2", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5 mb-2", children: [
                /* @__PURE__ */ jsx(Users, { className: "w-3.5 h-3.5 text-amber-500" }),
                " ",
                "Passagers"
              ] }),
              /* @__PURE__ */ jsx("div", { className: "flex-1 flex items-center mt-1", children: /* @__PURE__ */ jsx(
                StepperInput,
                {
                  value: data.adults_count,
                  onChange: (v) => setData("adults_count", v),
                  min: 1,
                  max: 7
                }
              ) })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-3", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(Briefcase, { className: "w-3.5 h-3.5 text-amber-500" }),
                " ",
                "Bagages"
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs text-slate-600 font-medium", children: "Grand (23kg max)" }),
                  /* @__PURE__ */ jsx(
                    StepperInput,
                    {
                      value: data.large_luggage_count,
                      onChange: (v) => setData("large_luggage_count", v),
                      min: 0,
                      max: 5
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-xs text-slate-600 font-medium", children: "Petit" }),
                  /* @__PURE__ */ jsx(
                    StepperInput,
                    {
                      value: data.small_luggage_count,
                      onChange: (v) => setData("small_luggage_count", v),
                      min: 0,
                      max: 4
                    }
                  )
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/60 shadow-sm space-y-2", children: [
            /* @__PURE__ */ jsxs("label", { className: "text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx(MessageSquare, { className: "w-3.5 h-3.5 text-amber-500" }),
              " ",
              "Consignes et exigences (Optionnel)"
            ] }),
            /* @__PURE__ */ jsx(
              "textarea",
              {
                placeholder: "Besoins spécifiques, instructions de vol, etc...",
                value: data.notes,
                onChange: (e) => setData("notes", e.target.value),
                className: "w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 focus:outline-none focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 focus:bg-white text-xs text-slate-800 min-h-[90px] resize-none transition-all"
              }
            )
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "lg:col-span-5 lg:sticky lg:top-28", children: /* @__PURE__ */ jsxs("div", { className: "bg-slate-950 rounded-2xl p-6 shadow-xl text-white border border-slate-800 relative overflow-hidden", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute -right-16 -top-16 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" }),
        /* @__PURE__ */ jsx("h3", { className: "text-amber-500 font-bold uppercase text-[11px] tracking-wider mb-6 pb-4 border-b border-white/5", children: "Récapitulatif de la commande" }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4 text-xs mb-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-white/5 rounded-xl p-3.5 border border-white/5 space-y-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("p", { className: "text-[9px] font-bold text-slate-500 uppercase tracking-wider", children: "Début" }),
                /* @__PURE__ */ jsx("p", { className: "font-semibold text-slate-200 mt-0.5 ", children: data.start_time ? formatDate(
                  data.start_time
                ) : "Non défini" })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("p", { className: "text-[9px] font-bold text-slate-500 uppercase tracking-wider", children: "Fin estimée" }),
                /* @__PURE__ */ jsx("p", { className: "font-semibold text-amber-500 mt-0.5 ", children: endTime ? formatDate(endTime) : "--:--" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 pt-2 border-t border-white/5 text-[11px]", children: [
              /* @__PURE__ */ jsx(MapPin, { className: "w-3.5 h-3.5 text-amber-500 shrink-0" }),
              /* @__PURE__ */ jsx("p", { className: "italic  text-slate-300", children: data.pickup_address || "Lieu à préciser" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-white/5 rounded-xl p-2.5 border border-white/5 flex items-center justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-400 text-[11px]", children: "Passager(s)" }),
              /* @__PURE__ */ jsx("span", { className: "font-bold text-slate-100", children: data.adults_count })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-white/5 rounded-xl p-2.5 border border-white/5 flex items-center justify-between", children: [
              /* @__PURE__ */ jsx("span", { className: "text-slate-400 text-[11px]", children: "Bagage(s)" }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-end", children: [
                /* @__PURE__ */ jsx("span", { className: "font-bold text-slate-100", children: data.large_luggage_count + data.small_luggage_count }),
                (data.large_luggage_count > 0 || data.small_luggage_count > 0) && /* @__PURE__ */ jsxs("span", { className: "text-[9px] text-slate-400 mt-0.5 text-right", children: [
                  data.large_luggage_count,
                  " grand(s), ",
                  data.small_luggage_count,
                  " petit(s)"
                ] })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mb-2 bg-white/5 p-4 rounded-xl border border-white/5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1", children: [
            "Estimation forfaitaire (",
            data.duration_hours,
            "h)"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-baseline gap-1", children: [
            /* @__PURE__ */ jsx("span", { className: "text-3xl font-black text-amber-500 tracking-tight", children: totalPrice.toLocaleString() }),
            /* @__PURE__ */ jsx("span", { className: "text-xs font-semibold text-amber-500 uppercase", children: "FCFA" })
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-slate-400 mt-1.5 italic", children: [
            "Taux horaire appliqué :",
            " ",
            Number(
              pricing.hourly_rate
            ).toLocaleString(),
            " ",
            "FCFA/h"
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "flex text-[10px] text-slate-400 mt-1.5 italic", children: [
            /* @__PURE__ */ jsx(CheckCircle, { className: "w-3.5 h-3.5 mr-2 text-amber-500 shrink-0" }),
            " ",
            /* @__PURE__ */ jsx("span", { className: "text-amber-500", children: "Carburant et frais de route à la charge du client" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: handleSubmit,
              disabled: processing || !data.start_time || !data.pickup_address,
              className: "w-full bg-amber-500 text-slate-950 py-3 rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-amber-400 active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 disabled:opacity-20 disabled:cursor-not-allowed group",
              children: [
                processing ? /* @__PURE__ */ jsx("span", { className: "w-4 h-4 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" }) : /* @__PURE__ */ jsx("span", { children: "Confirmer la réservation" }),
                /* @__PURE__ */ jsx(ChevronRight, { className: "w-4 h-4 group-hover:translate-x-0.5 transition-transform" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-2 text-[10px] text-slate-500 uppercase font-bold tracking-widest my-1", children: [
            /* @__PURE__ */ jsx("span", { className: "h-px bg-slate-800 flex-1" }),
            /* @__PURE__ */ jsx("span", { children: "ou" }),
            /* @__PURE__ */ jsx("span", { className: "h-px bg-slate-800 flex-1" })
          ] }),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("devis.index", { ...data }),
              type: "button",
              as: "button",
              className: "w-full bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white py-3 rounded-xl font-bold text-xs uppercase tracking-wider active:scale-[0.99] transition-all flex items-center justify-center gap-2 group",
              children: [
                /* @__PURE__ */ jsx("span", { children: "Demander un devis personnalisé" }),
                /* @__PURE__ */ jsx(ChevronRight, { className: "w-4 h-4 text-slate-500 group-hover:text-white group-hover:translate-x-0.5 transition-transform" })
              ]
            }
          )
        ] })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsx(
      CalendarModal,
      {
        isOpen: isCalendarOpen,
        onClose: () => setIsCalendarOpen(false),
        onSelect: (date) => onSelectDateTime(date),
        bookings
      }
    )
  ] });
}
function calculerPrixReservation(dureeHeures, dateReservation, prixParHeure = 15e3) {
  const dateObj = new Date(dateReservation);
  const heureDebut = dateObj.getHours();
  if (dureeHeures >= 24) {
    return 2e5;
  }
  if (dureeHeures >= 10) {
    if (heureDebut >= 8 && heureDebut < 18) {
      return 1e5;
    }
    return dureeHeures * prixParHeure;
  }
  if (dureeHeures >= 4) {
    return 5e4;
  }
  return dureeHeures * prixParHeure;
}
export {
  EventDetails as default
};
