import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useMemo } from "react";
import { Head } from "@inertiajs/react";
import { Search, Calendar, Eye, ChevronLeft, ChevronRight, FilterX } from "lucide-react";
import { f as formatDate } from "./formatters-Dx77TuBc.js";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-CA9xhxbb.js";
import "sonner";
function Index({ payments }) {
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  console.log("paiements", payments);
  const filteredPayments = useMemo(() => {
    return payments.filter(
      (p) => p.booking?.user?.name.toLowerCase().includes(search.toLowerCase()) || p.booking?.user?.email.toLowerCase().includes(search.toLowerCase())
    );
  }, [search]);
  const getStatusBadge = (status) => {
    const styles = {
      success: "bg-emerald-50 text-emerald-700 border-emerald-100"
    };
    const labels = {
      success: "Succès"
    };
    return /* @__PURE__ */ jsx(
      "span",
      {
        className: `px-2.5 py-1 rounded-full text-[11px] font-bold border uppercase tracking-wider ${styles[status]}`,
        children: labels[status]
      }
    );
  };
  const [isOpen, setIsOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(
    null
  );
  return /* @__PURE__ */ jsxs(AuthenticatedLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Paiements" }),
    /* @__PURE__ */ jsx("div", { className: "min-h-screen bg-gradient-to-br from-slate-50 to-slate-100/80", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto p-4 sm:p-6 lg:p-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row xl:items-center xl:justify-between gap-6 mb-8", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h1", { className: "text-3xl font-black tracking-tight text-slate-900", children: "Gestion des Paiements" }),
          /* @__PURE__ */ jsx("p", { className: "mt-2 text-slate-500", children: "Gérez et consultez tous les paiements clients." })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 w-full xl:w-auto", children: /* @__PURE__ */ jsxs("div", { className: "bg-white border border-slate-200 rounded-2xl px-5 py-4 shadow-sm", children: [
          /* @__PURE__ */ jsx("p", { className: "text-xs font-medium text-slate-400 uppercase", children: "Total" }),
          /* @__PURE__ */ jsx("h3", { className: "text-2xl font-black text-slate-900 mt-1", children: payments.length })
        ] }) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "bg-white border border-slate-200 rounded-2xl p-4 shadow-sm mb-6", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col lg:flex-row lg:items-center gap-4 justify-between", children: [
        /* @__PURE__ */ jsxs("div", { className: "relative w-full lg:max-w-md", children: [
          /* @__PURE__ */ jsx(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              placeholder: "Rechercher un client, email ",
              value: search,
              onChange: (e) => setSearch(e.target.value),
              className: "\n                                    w-full\n                                    pl-11\n                                    pr-4\n                                    py-3\n                                    bg-slate-50\n                                    border\n                                    border-slate-200\n                                    rounded-xl\n                                    text-sm\n                                    text-slate-700\n                                    placeholder:text-slate-400\n                                    focus:outline-none\n                                    focus:ring-4\n                                    focus:ring-amber-500/10\n                                    focus:border-amber-500\n                                    transition-all\n                                "
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between lg:justify-end gap-3", children: [
          /* @__PURE__ */ jsxs("span", { className: "text-sm text-slate-500", children: [
            filteredPayments.length,
            " résultat(s)"
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "\n                                    px-4 py-2.5\n                                    rounded-xl\n                                    border border-slate-200\n                                    bg-white\n                                    hover:bg-slate-50\n                                    text-slate-600\n                                    text-sm\n                                    font-medium\n                                    transition-all\n                                ",
              children: "Filtres"
            }
          )
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs(
        "div",
        {
          className: "\n                    bg-white\n                    border\n                    border-slate-200\n                    rounded-3xl\n                    shadow-sm\n                    overflow-hidden\n                ",
          children: [
            /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full min-w-[1100px]", children: [
              /* @__PURE__ */ jsx("thead", { className: "bg-slate-50 sticky top-0 z-10", children: /* @__PURE__ */ jsxs("tr", { className: "border-b border-slate-200", children: [
                /* @__PURE__ */ jsx("th", { className: "px-6 py-5 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Client" }),
                /* @__PURE__ */ jsx("th", { className: "px-6 py-5 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Type" }),
                /* @__PURE__ */ jsx("th", { className: "px-6 py-5 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Statut" }),
                /* @__PURE__ */ jsx("th", { className: "px-6 py-5 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Date" }),
                /* @__PURE__ */ jsx("th", { className: "px-6 py-5 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Trajet" }),
                /* @__PURE__ */ jsx("th", { className: "px-6 py-5 text-right text-xs font-bold uppercase tracking-wider text-slate-400", children: "Montant" }),
                /* @__PURE__ */ jsx("th", { className: "px-6 py-5 text-right text-xs font-bold uppercase tracking-wider text-slate-400", children: "Action" })
              ] }) }),
              /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-slate-100", children: filteredPayments.map((payment) => /* @__PURE__ */ jsxs(
                "tr",
                {
                  className: "\n                                            hover:bg-amber-50/40\n                                            transition-all\n                                            duration-200\n                                            group\n                                        ",
                  children: [
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-5", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
                      /* @__PURE__ */ jsx(
                        "div",
                        {
                          className: "\n                                                    w-11 h-11\n                                                    rounded-2xl\n                                                    bg-gradient-to-br\n                                                    from-amber-400\n                                                    to-amber-500\n                                                    text-white\n                                                    flex\n                                                    items-center\n                                                    justify-center\n                                                    font-bold\n                                                    shadow-sm\n                                                ",
                          children: payment.booking?.user?.name.charAt(
                            0
                          )
                        }
                      ),
                      /* @__PURE__ */ jsxs("div", { children: [
                        /* @__PURE__ */ jsx("p", { className: "font-semibold text-slate-900", children: payment.booking?.user?.name }),
                        /* @__PURE__ */ jsx("p", { className: "text-sm text-slate-500", children: payment.booking?.user?.email })
                      ] })
                    ] }) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-5", children: /* @__PURE__ */ jsx(
                      "span",
                      {
                        className: "\n                                                inline-flex\n                                                items-center\n                                                px-3 py-1\n                                                rounded-full\n                                                bg-slate-100\n                                                text-slate-700\n                                                text-xs\n                                                font-semibold\n                                            ",
                        children: payment.booking?.type === "course_fixed" ? "Course fixe" : payment.booking?.type === "event_hourly" ? "Location Horaire" : ""
                      }
                    ) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-5", children: getStatusBadge(payment.status) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-5", children: /* @__PURE__ */ jsx("div", { className: "space-y-1", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-sm font-semibold text-slate-800", children: [
                      /* @__PURE__ */ jsx(Calendar, { className: "w-4 h-4 text-amber-500" }),
                      formatDate(
                        payment.created_at
                      )
                    ] }) }) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-5 max-w-[260px]", children: /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
                        /* @__PURE__ */ jsx("div", { className: "w-2 h-2 rounded-full bg-emerald-500 mt-1.5" }),
                        /* @__PURE__ */ jsx("p", { className: "text-sm text-slate-700 truncate", children: payment.booking?.pickup_address })
                      ] }),
                      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
                        /* @__PURE__ */ jsx("div", { className: "w-2 h-2 rounded-full bg-slate-300 mt-1.5" }),
                        /* @__PURE__ */ jsx("p", { className: "text-sm text-slate-400 truncate", children: payment.booking?.dropoff_address || "Location horaire" })
                      ] })
                    ] }) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-5 text-right", children: /* @__PURE__ */ jsxs("div", { children: [
                      /* @__PURE__ */ jsx("p", { className: "font-black text-slate-900 text-lg", children: payment.amount.toLocaleString() }),
                      /* @__PURE__ */ jsx("span", { className: "text-xs text-amber-600 font-semibold", children: "FCFA" })
                    ] }) }),
                    /* @__PURE__ */ jsx("td", { className: "px-6 py-5 text-right", children: /* @__PURE__ */ jsx(
                      "button",
                      {
                        className: "\n                                                    inline-flex\n                                                    items-center\n                                                    justify-center\n                                                    w-10 h-10\n                                                    rounded-xl\n                                                    border border-slate-200\n                                                    bg-white\n                                                    text-slate-500\n                                                    hover:bg-amber-500\n                                                    hover:text-white\n                                                    hover:border-amber-500\n                                                    transition-all\n                                                    shadow-sm\n                                                ",
                        children: /* @__PURE__ */ jsx(Eye, { className: "w-4 h-4" })
                      }
                    ) })
                  ]
                },
                payment.id
              )) })
            ] }) }),
            /* @__PURE__ */ jsxs(
              "div",
              {
                className: "\n                        flex\n                        flex-col\n                        md:flex-row\n                        items-center\n                        justify-between\n                        gap-4\n                        px-6\n                        py-5\n                        border-t\n                        border-slate-200\n                        bg-slate-50\n                    ",
                children: [
                  /* @__PURE__ */ jsxs("p", { className: "text-sm text-slate-500", children: [
                    "Affichage de",
                    " ",
                    /* @__PURE__ */ jsx("span", { className: "font-semibold text-slate-700", children: filteredPayments.length }),
                    " ",
                    "paiement(s)"
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsx(
                      "button",
                      {
                        className: "\n                                w-10 h-10\n                                rounded-xl\n                                border border-slate-200\n                                bg-white\n                                text-slate-500\n                                hover:bg-slate-100\n                                transition-all\n                            ",
                        children: /* @__PURE__ */ jsx(ChevronLeft, { className: "w-4 h-4" })
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      "button",
                      {
                        className: "\n                                w-10 h-10\n                                rounded-xl\n                                bg-amber-500\n                                text-white\n                                font-bold\n                                shadow-sm\n                            ",
                        children: "1"
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      "button",
                      {
                        className: "\n                                w-10 h-10\n                                rounded-xl\n                                border border-slate-200\n                                bg-white\n                                text-slate-500\n                                hover:bg-slate-100\n                                transition-all\n                            ",
                        children: /* @__PURE__ */ jsx(ChevronRight, { className: "w-4 h-4" })
                      }
                    )
                  ] })
                ]
              }
            )
          ]
        }
      ),
      filteredPayments.length === 0 && /* @__PURE__ */ jsxs(
        "div",
        {
          className: "\n                        mt-6\n                        bg-white\n                        border border-dashed border-slate-300\n                        rounded-3xl\n                        py-20\n                        text-center\n                    ",
          children: [
            /* @__PURE__ */ jsx(FilterX, { className: "w-14 h-14 text-slate-200 mx-auto mb-4" }),
            /* @__PURE__ */ jsx("h3", { className: "text-lg font-bold text-slate-700", children: "Aucun résultat trouvé" }),
            /* @__PURE__ */ jsx("p", { className: "text-slate-500 mt-2", children: "Essayez une autre recherche ou modifiez vos filtres." })
          ]
        }
      )
    ] }) })
  ] });
}
export {
  Index as default
};
