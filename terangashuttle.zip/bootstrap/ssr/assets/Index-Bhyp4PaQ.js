import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState, useMemo } from "react";
import { router, Head } from "@inertiajs/react";
import { X, User, Mail, Phone, Info, Briefcase, Users, MapPin, Clock, CreditCard, Loader2, CheckCircle, XCircle, AlertTriangle, Search, Calendar, Eye, ChevronLeft, ChevronRight, FilterX } from "lucide-react";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-CA9xhxbb.js";
import { f as formatDate, a as formatPrice } from "./formatters-Dx77TuBc.js";
import withReactContent from "sweetalert2-react-content";
import Swal from "sweetalert2";
import "sonner";
function BookingDetailModal({
  isOpen,
  onClose,
  booking
}) {
  if (!isOpen || !booking) return null;
  const MySwal = withReactContent(Swal);
  const [processing, setProcessing] = useState(false);
  const updateStatus = async (newStatus) => {
    const result = await MySwal.fire({
      title: "Opération de changement de statut de la reservation",
      text: `${newStatus === "validated" ? "Accepter" : "Refuser"} la reservation du client ?. Cette operation est irréversible.`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Oui, je confirme !",
      cancelButtonText: "Annuler",
      reverseButtons: true
      // Place le bouton de confirmation à droite
    });
    if (result.isConfirmed) {
      try {
        router.patch(
          route("admin.booking.update", booking.id),
          {
            status: newStatus
          },
          {
            onSuccess: () => onClose(),
            onStart: () => setProcessing(true),
            onFinish: () => {
              setProcessing(false);
              window.location.reload();
            }
          }
        );
      } catch (error) {
      }
    }
  };
  return /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm", children: /* @__PURE__ */ jsxs("div", { className: "bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300", children: [
    /* @__PURE__ */ jsxs("div", { className: "px-8 py-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("h2", { className: "text-xl font-black text-slate-900 italic uppercase", children: [
          "Fiche Réservation",
          " ",
          /* @__PURE__ */ jsxs("span", { className: "text-amber-500", children: [
            "#",
            booking.id
          ] })
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "text-xs text-slate-500 font-medium uppercase tracking-widest mt-1", children: [
          "Créée le ",
          formatDate(booking.created_at)
        ] })
      ] }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: onClose,
          className: "p-2 hover:bg-white rounded-full border border-transparent hover:border-slate-200 transition-all text-slate-400 hover:text-slate-900",
          children: /* @__PURE__ */ jsx(X, { className: "w-6 h-6" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "p-8 max-h-[70vh] overflow-y-auto custom-scrollbar", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("h3", { className: "text-[10px] font-black text-amber-600 uppercase tracking-[0.2em] flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(User, { className: "w-3 h-3" }),
            " Informations Client"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-slate-50 rounded-2xl p-4 space-y-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-sm", children: /* @__PURE__ */ jsx(User, { className: "w-4 h-4 text-slate-400" }) }),
              /* @__PURE__ */ jsx("span", { className: "font-bold text-slate-800 text-sm", children: booking.user?.name })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-sm", children: /* @__PURE__ */ jsx(Mail, { className: "w-4 h-4 text-slate-400" }) }),
              /* @__PURE__ */ jsx("span", { className: "text-sm text-slate-600", children: booking.user?.email })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-sm", children: /* @__PURE__ */ jsx(Phone, { className: "w-4 h-4 text-slate-400" }) }),
              /* @__PURE__ */ jsx("span", { className: "text-sm text-slate-600", children: booking.user?.phone || "Non renseigné" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-sm", children: /* @__PURE__ */ jsx(Info, { className: "w-4 h-4 text-slate-400" }) }),
              /* @__PURE__ */ jsx("span", { className: "text-sm text-slate-600", children: booking.notes || "Aucune note supplémentaire" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("h3", { className: "text-[10px] font-black text-amber-600 uppercase tracking-[0.2em] flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Briefcase, { className: "w-3 h-3" }),
            " Logistique & Capacité"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-slate-50 rounded-2xl p-4 text-center", children: [
              /* @__PURE__ */ jsx(Users, { className: "w-5 h-5 text-slate-400 mx-auto mb-1" }),
              /* @__PURE__ */ jsx("p", { className: "text-lg font-black text-slate-900", children: booking.adults_count + booking.children_count }),
              /* @__PURE__ */ jsx("p", { className: "text-[9px] font-bold text-slate-400 uppercase", children: "Passagers" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-slate-50 rounded-2xl p-4 text-center", children: [
              /* @__PURE__ */ jsx(Briefcase, { className: "w-5 h-5 text-slate-400 mx-auto mb-1" }),
              /* @__PURE__ */ jsx("p", { className: "text-lg font-black text-slate-900", children: booking.luggage_count }),
              /* @__PURE__ */ jsx("p", { className: "text-[9px] font-bold text-slate-400 uppercase", children: "Bagages" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "md:col-span-2 space-y-4", children: [
          /* @__PURE__ */ jsxs("h3", { className: "text-[10px] font-black text-amber-600 uppercase tracking-[0.2em] flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(MapPin, { className: "w-3 h-3" }),
            " Détails du Trajet"
          ] }),
          /* @__PURE__ */ jsx("div", { className: "border border-slate-100 rounded-3xl p-6 relative", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-6 relative", children: [
            /* @__PURE__ */ jsx("div", { className: "absolute left-4 top-5 bottom-5 w-0.5 border-l-2 border-dashed border-slate-200" }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-4 relative z-10", children: [
              /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-full bg-amber-500 border-4 border-white shadow-sm shrink-0 flex items-center justify-center text-white text-[10px] font-bold", children: "A" }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("p", { className: "text-[10px] font-bold text-slate-400 uppercase", children: "Prise en charge" }),
                /* @__PURE__ */ jsx("p", { className: "font-bold text-slate-800 italic", children: booking.pickup_address }),
                /* @__PURE__ */ jsxs("p", { className: "text-xs text-amber-600 font-medium flex items-center gap-1 mt-1", children: [
                  /* @__PURE__ */ jsx(Clock, { className: "w-3 h-3" }),
                  " ",
                  formatDate(booking.start_time)
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-4 relative z-10", children: [
              /* @__PURE__ */ jsx("div", { className: "w-8 h-8 rounded-full bg-slate-900 border-4 border-white shadow-sm shrink-0 flex items-center justify-center text-white text-[10px] font-bold", children: "B" }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("p", { className: "text-[10px] font-bold text-slate-400 uppercase", children: "Destination" }),
                /* @__PURE__ */ jsx("p", { className: "font-bold text-slate-800 italic", children: booking.dropoff_address || "Mise à disposition (Fin de service)" }),
                /* @__PURE__ */ jsxs("p", { className: "text-xs text-amber-600 font-medium flex items-center gap-1 mt-1", children: [
                  /* @__PURE__ */ jsx(Clock, { className: "w-3 h-3" }),
                  " ",
                  formatDate(booking.end_time)
                ] })
              ] })
            ] })
          ] }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 bg-slate-900 rounded-3xl p-6 flex items-center justify-between text-white shadow-xl shadow-slate-900/20", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsx("div", { className: "w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center", children: /* @__PURE__ */ jsx(CreditCard, { className: "w-6 h-6 text-amber-400" }) }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("p", { className: "text-[10px] font-bold text-white/50 uppercase tracking-widest", children: "Total à payer" }),
            /* @__PURE__ */ jsxs("p", { className: "text-2xl font-black italic", children: [
              formatPrice(booking.total_amount, false),
              " ",
              /* @__PURE__ */ jsx("span", { className: "text-sm not-italic text-amber-500", children: "CFA" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
          /* @__PURE__ */ jsx("p", { className: "text-[10px] font-bold text-white/50 uppercase tracking-widest mb-1", children: "Statut Actuel" }),
          /* @__PURE__ */ jsx("span", { className: "text-[10px] font-black uppercase px-3 py-1 bg-white/10 rounded-full border border-white/20", children: booking.status })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "px-8 py-6 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-center gap-3", children: [
      booking.status === "pending" && /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => updateStatus("validated"),
          disabled: processing,
          className: "flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-2xl font-bold uppercase text-[10px] tracking-widest transition-all",
          children: processing ? /* @__PURE__ */ jsx(Loader2, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(CheckCircle, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsx("span", { children: "Valider la demande" })
          ] })
        }
      ),
      booking.status !== "cancelled" && booking.status !== "finished" && /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => updateStatus("cancelled"),
          disabled: processing,
          className: "flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-white hover:bg-red-50 text-red-600 border border-red-100 py-3 rounded-2xl font-bold uppercase text-[10px] tracking-widest transition-all",
          children: processing ? /* @__PURE__ */ jsx(Loader2, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(XCircle, { className: "w-4 h-4" }),
            " ",
            /* @__PURE__ */ jsx("span", { children: "Annuler la réservation" })
          ] })
        }
      ),
      booking.status === "validated" && /* @__PURE__ */ jsxs("div", { className: "w-full text-center py-2 flex items-center justify-center gap-2 text-blue-600 bg-blue-50 rounded-xl border border-blue-100", children: [
        /* @__PURE__ */ jsx(AlertTriangle, { className: "w-4 h-4" }),
        /* @__PURE__ */ jsx("span", { className: "text-[10px] font-bold uppercase", children: "En attente du paiement client" })
      ] })
    ] })
  ] }) });
}
const STATUS_CONFIG = {
  pending: {
    label: "En attente",
    style: "bg-amber-50 text-amber-700 border-amber-200/60"
  },
  validated: {
    label: "À payer",
    style: "bg-blue-50 text-blue-700 border-blue-200/60"
  },
  paid: {
    label: "Payé",
    style: "bg-emerald-50 text-emerald-700 border-emerald-200/60"
  },
  cancelled: {
    label: "Annulé",
    style: "bg-slate-100 text-slate-600 border-slate-200"
  },
  finished: {
    label: "Terminé",
    style: "bg-slate-100 text-slate-600 border-slate-200"
  }
};
function AdminBookingsIndex({
  bookings
}) {
  const [search, setSearch] = useState("");
  const [activeStatus, setActiveStatus] = useState(
    "all"
  );
  const [isOpen, setIsOpen] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState(
    null
  );
  withReactContent(Swal);
  const filteredBookings = useMemo(() => {
    return bookings.filter((b) => {
      const matchesSearch = b.user?.name.toLowerCase().includes(search.toLowerCase()) || b.user?.email.toLowerCase().includes(search.toLowerCase()) || b.pickup_address.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = activeStatus === "all" || b.status === activeStatus;
      return matchesSearch && matchesStatus;
    });
  }, [bookings, search, activeStatus]);
  const handleOpenModal = (booking) => {
    setSelectedBooking(booking);
    setIsOpen(true);
  };
  const filterTabs = [
    { label: "Tous", value: "all" },
    { label: "À confirmer", value: "pending" },
    { label: "À payer", value: "validated" },
    { label: "Payés", value: "paid" },
    { label: "Annulés", value: "cancelled" },
    { label: "Terminés", value: "finished" }
  ];
  return /* @__PURE__ */ jsxs(AuthenticatedLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Configuration des Réservations" }),
    /* @__PURE__ */ jsx("div", { className: "min-h-screen bg-slate-50/50", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto p-4 sm:p-6 lg:p-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row xl:items-center xl:justify-between gap-6 mb-8", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight text-slate-950", children: "Gestion des Réservations" }),
          /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-slate-500", children: "Suivez, validez et consultez l'ensemble des trajets et réservations clients." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 w-full xl:w-auto", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-white border border-slate-200/60 rounded-xl p-4 shadow-sm", children: [
            /* @__PURE__ */ jsx("p", { className: "text-[11px] font-semibold text-slate-400 uppercase tracking-wider", children: "Total" }),
            /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-slate-900 mt-1", children: bookings.length })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white border border-slate-200/60 rounded-xl p-4 shadow-sm", children: [
            /* @__PURE__ */ jsx("p", { className: "text-[11px] font-semibold text-amber-600 uppercase tracking-wider", children: "En attente" }),
            /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-amber-600 mt-1", children: bookings.filter(
              (b) => b.status === "pending"
            ).length })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white border border-slate-200/60 rounded-xl p-4 shadow-sm", children: [
            /* @__PURE__ */ jsx("p", { className: "text-[11px] font-semibold text-emerald-600 uppercase tracking-wider", children: "Payées" }),
            /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-emerald-600 mt-1", children: bookings.filter(
              (b) => b.status === "paid"
            ).length })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white border border-slate-200/60 rounded-xl p-4 shadow-sm", children: [
            /* @__PURE__ */ jsx("p", { className: "text-[11px] font-semibold text-slate-500 uppercase tracking-wider", children: "Annulées" }),
            /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-slate-700 mt-1", children: bookings.filter(
              (b) => b.status === "cancelled"
            ).length })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-white border border-slate-200/60 rounded-xl p-4 shadow-sm", children: [
            /* @__PURE__ */ jsx("p", { className: "text-[11px] font-semibold text-slate-500 uppercase tracking-wider", children: "Terminées" }),
            /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-slate-700 mt-1", children: bookings.filter(
              (b) => b.status === "finished"
            ).length })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white border border-slate-200/60 rounded-2xl p-4 shadow-sm mb-6 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col lg:flex-row lg:items-center gap-4 justify-between", children: [
          /* @__PURE__ */ jsxs("div", { className: "relative w-full lg:max-w-md", children: [
            /* @__PURE__ */ jsx(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                placeholder: "Rechercher un client, email ou adresse...",
                value: search,
                onChange: (e) => setSearch(e.target.value),
                className: "w-full pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 transition-all"
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex items-center overflow-x-auto pb-1 lg:pb-0 no-scrollbar -mx-4 px-4 lg:mx-0 lg:px-0", children: /* @__PURE__ */ jsx("div", { className: "flex bg-slate-100 p-1 rounded-xl border border-slate-200/40 min-w-max", children: filterTabs.map((tab) => {
            const count = tab.value === "all" ? bookings.length : bookings.filter(
              (b) => b.status === tab.value
            ).length;
            return /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: () => setActiveStatus(tab.value),
                className: `px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 flex items-center gap-2 ${activeStatus === tab.value ? "bg-white text-slate-950 shadow-sm font-bold" : "text-slate-500 hover:text-slate-800"}`,
                children: [
                  tab.label,
                  /* @__PURE__ */ jsx(
                    "span",
                    {
                      className: `text-[10px] px-1.5 py-0.5 rounded-md ${activeStatus === tab.value ? "bg-slate-950 text-white" : "bg-slate-200 text-slate-600"}`,
                      children: count
                    }
                  )
                ]
              },
              tab.value
            );
          }) }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-xs text-slate-400 font-medium pt-1 border-t border-slate-50 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            "Filtre actif :",
            " ",
            /* @__PURE__ */ jsx("span", { className: "text-slate-700 font-semibold", children: filterTabs.find(
              (t) => t.value === activeStatus
            )?.label })
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            filteredBookings.length,
            " résultat(s) trouvé(s)"
          ] })
        ] })
      ] }),
      filteredBookings.length > 0 ? /* @__PURE__ */ jsxs("div", { className: "bg-white border border-slate-200/60 rounded-2xl shadow-sm overflow-hidden", children: [
        /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full min-w-[1100px]", children: [
          /* @__PURE__ */ jsx("thead", { className: "bg-slate-50/70 border-b border-slate-200", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { className: "px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "N*" }),
            /* @__PURE__ */ jsx("th", { className: "px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Client" }),
            /* @__PURE__ */ jsx("th", { className: "px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Statut" }),
            /* @__PURE__ */ jsx("th", { className: "px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Trajet" }),
            /* @__PURE__ */ jsx("th", { className: "px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Type" }),
            /* @__PURE__ */ jsx("th", { className: "px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400", children: "Date & Heure" }),
            /* @__PURE__ */ jsx("th", { className: "px-6 py-4 text-right text-xs font-bold uppercase tracking-wider text-slate-400", children: "Montant (FCFA)" }),
            /* @__PURE__ */ jsx("th", { className: "px-6 py-4 text-right text-xs font-bold uppercase tracking-wider text-slate-400", children: "Action" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-slate-100", children: filteredBookings.map((booking) => {
            const config = STATUS_CONFIG[booking.status] || STATUS_CONFIG.pending;
            return /* @__PURE__ */ jsxs(
              "tr",
              {
                className: "hover:bg-slate-50/80 transition-colors group",
                children: [
                  /* @__PURE__ */ jsx("td", { className: "px-6 py-4.5", children: /* @__PURE__ */ jsx("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsx("span", { className: "text-sm font-semibold text-slate-900", children: booking.id }) }) }),
                  /* @__PURE__ */ jsx("td", { className: "px-6 py-4.5", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-xl bg-gradient-to-br from-blue-400 to-purple-500 text-white flex items-center justify-center font-bold text-sm shadow-sm shrink-0", children: booking.user?.name.charAt(0).toUpperCase() }),
                    /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsx("p", { className: "font-semibold text-slate-900 text-sm truncate", children: booking.user?.name }),
                      /* @__PURE__ */ jsx("p", { className: "text-xs text-slate-400 truncate", children: booking.user?.email })
                    ] })
                  ] }) }),
                  /* @__PURE__ */ jsx("td", { className: "px-6 py-4.5", children: /* @__PURE__ */ jsx(
                    "span",
                    {
                      className: `px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${config.style}`,
                      children: config.label
                    }
                  ) }),
                  /* @__PURE__ */ jsx("td", { className: "px-6 py-4.5 max-w-[240px]", children: /* @__PURE__ */ jsxs("div", { className: "relative pl-4 space-y-1.5 before:absolute before:left-1 before:top-1.5 before:bottom-1.5 before:w-0.5 before:bg-slate-100", children: [
                    /* @__PURE__ */ jsxs("div", { className: "relative flex items-center", children: [
                      /* @__PURE__ */ jsx("div", { className: "absolute -left-[14.5px] w-2 h-2 rounded-full bg-emerald-500" }),
                      /* @__PURE__ */ jsx("p", { className: "text-xs text-slate-700 truncate font-medium", children: booking.pickup_address })
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "relative flex items-center", children: [
                      /* @__PURE__ */ jsx("div", { className: "absolute -left-[14.5px] w-2 h-2 rounded-full bg-slate-300" }),
                      /* @__PURE__ */ jsx("p", { className: "text-xs text-slate-400 truncate", children: booking.dropoff_address || "Mise à disposition" })
                    ] })
                  ] }) }),
                  /* @__PURE__ */ jsx("td", { className: "px-6 py-4.5", children: /* @__PURE__ */ jsx("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700 text-xs font-medium", children: booking.type === "course_fixed" ? "Course" : booking.type === "event_hourly" ? "Location" : "Distance" }) }),
                  /* @__PURE__ */ jsx("td", { className: "px-6 py-4.5", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 text-xs font-semibold text-slate-800", children: [
                      /* @__PURE__ */ jsx(Calendar, { className: "w-3.5 h-3.5 text-slate-400" }),
                      new Date(
                        booking.start_time
                      ).toLocaleDateString(
                        "fr-FR",
                        {
                          day: "2-digit",
                          month: "2-digit",
                          year: "numeric"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "text-[11px] text-slate-400 mt-0.5 pl-5", children: [
                      new Date(
                        booking.start_time
                      ).toLocaleTimeString(
                        "fr-FR",
                        {
                          hour: "2-digit",
                          minute: "2-digit"
                        }
                      ),
                      " - ",
                      new Date(
                        booking.end_time
                      ).toLocaleTimeString(
                        "fr-FR",
                        {
                          hour: "2-digit",
                          minute: "2-digit"
                        }
                      )
                    ] })
                  ] }) }),
                  /* @__PURE__ */ jsx("td", { className: "px-6 py-4.5 text-right", children: /* @__PURE__ */ jsx("span", { className: "font-bold text-slate-950 text-base", children: formatPrice(
                    booking.total_amount,
                    false
                  ) }) }),
                  /* @__PURE__ */ jsx("td", { className: "px-6 py-4.5 text-right", children: /* @__PURE__ */ jsx(
                    "button",
                    {
                      onClick: () => handleOpenModal(
                        booking
                      ),
                      className: "inline-flex items-center justify-center w-8 h-8 rounded-lg border border-slate-200 bg-white text-slate-500 hover:bg-slate-950 hover:text-white hover:border-slate-950 transition-all shadow-sm",
                      children: /* @__PURE__ */ jsx(Eye, { className: "w-3.5 h-3.5" })
                    }
                  ) })
                ]
              },
              booking.id
            );
          }) })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-4 px-6 py-4 border-t border-slate-100 bg-slate-50/50", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs text-slate-400 font-medium", children: [
            "Affichage de",
            " ",
            /* @__PURE__ */ jsx("span", { className: "font-semibold text-slate-700", children: filteredBookings.length }),
            " ",
            "réservation(s)"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsx("button", { className: "w-8 h-8 rounded-lg border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 transition-colors flex items-center justify-center", children: /* @__PURE__ */ jsx(ChevronLeft, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx("button", { className: "w-8 h-8 rounded-lg bg-slate-950 text-white font-bold text-xs shadow-sm flex items-center justify-center", children: "1" }),
            /* @__PURE__ */ jsx("button", { className: "w-8 h-8 rounded-lg border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 transition-colors flex items-center justify-center", children: /* @__PURE__ */ jsx(ChevronRight, { className: "w-4 h-4" }) })
          ] })
        ] })
      ] }) : (
        /* EMPTY STATE */
        /* @__PURE__ */ jsxs("div", { className: "mt-6 bg-white border border-dashed border-slate-200 rounded-2xl py-16 text-center shadow-sm", children: [
          /* @__PURE__ */ jsx(FilterX, { className: "w-10 h-10 text-slate-300 mx-auto mb-3" }),
          /* @__PURE__ */ jsx("h3", { className: "text-base font-semibold text-slate-800", children: "Aucune réservation correspondante" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-slate-400 mt-1 max-w-xs mx-auto", children: "Modifiez les termes de votre recherche ou changez de filtre de statut pour trouver le trajet désiré." })
        ] })
      )
    ] }) }),
    /* @__PURE__ */ jsx(
      BookingDetailModal,
      {
        isOpen,
        onClose: () => setIsOpen(false),
        booking: selectedBooking
      }
    )
  ] });
}
export {
  AdminBookingsIndex as default
};
