import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { useForm, Head } from "@inertiajs/react";
import { LogIn, Mail, Lock, Loader2 } from "lucide-react";
function Login() {
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: false
  });
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("admin.auth.do-login"), {
      onFinish: () => reset("password")
    });
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Connexion Administration" }),
    /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-slate-900 px-4 sm:px-6 lg:px-8", children: /* @__PURE__ */ jsxs("div", { className: "w-full max-w-md space-y-8 rounded-2xl bg-slate-800 p-8 shadow-xl border border-slate-700", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsx("div", { className: "mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400", children: /* @__PURE__ */ jsx(LogIn, { className: "h-6 w-6" }) }),
        /* @__PURE__ */ jsx("h2", { className: "mt-4 text-3xl font-bold tracking-tight text-white", children: "Espace Client" }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-slate-400", children: "Connectez-vous pour accéder au tableau de bord" })
      ] }),
      /* @__PURE__ */ jsxs("form", { className: "mt-8 space-y-6", onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-4 rounded-md", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              "label",
              {
                htmlFor: "email",
                className: "block text-sm font-medium text-slate-300",
                children: "Adresse Email"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "relative mt-1", children: [
              /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500", children: /* @__PURE__ */ jsx(Mail, { className: "h-5 w-5" }) }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  id: "email",
                  type: "email",
                  required: true,
                  value: data.email,
                  onChange: (e) => setData("email", e.target.value),
                  className: `block w-full rounded-lg border bg-slate-900 py-2.5 pl-10 pr-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 sm:text-sm ${errors.email ? "border-red-500 focus:border-red-500" : "border-slate-700 focus:border-indigo-500"}`,
                  placeholder: "admin@exemple.com"
                }
              )
            ] }),
            errors.email && /* @__PURE__ */ jsx("p", { className: "mt-1.5 text-sm text-red-400", children: errors.email })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              "label",
              {
                htmlFor: "password",
                className: "block text-sm font-medium text-slate-300",
                children: "Mot de passe"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "relative mt-1", children: [
              /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500", children: /* @__PURE__ */ jsx(Lock, { className: "h-5 w-5" }) }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  id: "password",
                  type: "password",
                  required: true,
                  value: data.password,
                  onChange: (e) => setData("password", e.target.value),
                  className: `block w-full rounded-lg border bg-slate-900 py-2.5 pl-10 pr-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 sm:text-sm ${errors.password ? "border-red-500 focus:border-red-500" : "border-slate-700 focus:border-indigo-500"}`,
                  placeholder: "••••••••"
                }
              )
            ] }),
            errors.password && /* @__PURE__ */ jsx("p", { className: "mt-1.5 text-sm text-red-400", children: errors.password })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              id: "remember",
              type: "checkbox",
              checked: data.remember,
              onChange: (e) => setData("remember", e.target.checked),
              className: "h-4 w-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 focus:ring-offset-slate-800"
            }
          ),
          /* @__PURE__ */ jsx(
            "label",
            {
              htmlFor: "remember",
              className: "ml-2 block text-sm text-slate-400",
              children: "Se souvenir de moi"
            }
          )
        ] }) }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
          "button",
          {
            type: "submit",
            disabled: processing,
            className: "relative flex w-full justify-center rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 disabled:opacity-50 transition-colors duration-200",
            children: processing ? /* @__PURE__ */ jsx(Loader2, { className: "h-5 w-5 animate-spin" }) : "Se connecter"
          }
        ) })
      ] })
    ] }) })
  ] });
}
export {
  Login as default
};
