import { jsxs, jsx } from "react/jsx-runtime";
import { Head } from "@inertiajs/react";
import DeleteUserForm from "./DeleteUserForm-CZcpQSfR.js";
import UpdatePasswordForm from "./UpdatePasswordForm-DUCcB3A4.js";
import UpdateProfileInformation from "./UpdateProfileInformationForm-C6qg-w6M.js";
import { U as UserLayout } from "./UserLayout-BtuPwiUA.js";
import "./TextInput-BpKdnAfj.js";
import "react";
import "./InputLabel-CE_n4Upz.js";
import "@headlessui/react";
import "./PrimaryButton-DgVfVBwo.js";
import "lucide-react";
import "sonner";
function Edit({
  mustVerifyEmail,
  status
}) {
  return /* @__PURE__ */ jsxs(UserLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Profil" }),
    /* @__PURE__ */ jsx("div", { className: "py-10", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8", children: [
      /* @__PURE__ */ jsx("div", { className: "bg-white p-4 shadow sm:rounded-lg sm:p-8", children: /* @__PURE__ */ jsx(
        UpdateProfileInformation,
        {
          mustVerifyEmail,
          status,
          className: "max-w-xl mt-5"
        }
      ) }),
      /* @__PURE__ */ jsx("div", { className: "bg-white p-4 shadow sm:rounded-lg sm:p-8", children: /* @__PURE__ */ jsx(UpdatePasswordForm, { className: "max-w-xl" }) }),
      /* @__PURE__ */ jsx("div", { className: "bg-white p-4 shadow sm:rounded-lg sm:p-8", children: /* @__PURE__ */ jsx(DeleteUserForm, { className: "max-w-xl" }) })
    ] }) })
  ] });
}
export {
  Edit as default
};
