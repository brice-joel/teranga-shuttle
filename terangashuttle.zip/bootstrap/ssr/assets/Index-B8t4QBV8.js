import { jsxs, jsx } from "react/jsx-runtime";
import { U as UserLayout } from "./UserLayout-BtuPwiUA.js";
import { useEffect } from "react";
import { usePage, useForm, Head } from "@inertiajs/react";
import { T as TextInput, I as InputError } from "./TextInput-BpKdnAfj.js";
import { I as InputLabel } from "./InputLabel-CE_n4Upz.js";
import { P as PrimaryButton } from "./PrimaryButton-DgVfVBwo.js";
import { MapPin } from "lucide-react";
import { S as StepperInput } from "./StepperInput-D7wEdr1K.js";
import "sonner";
function DevisForm({ queryParams }) {
  const { auth } = usePage().props;
  console.log("auth", auth);
  const { data, setData, post, processing, errors, transform } = useForm({
    user_name: queryParams.user_name || auth.user?.name || "",
    user_email: queryParams.user_email || auth.user?.email || "",
    pickup_address: queryParams.pickup_address || queryParams.pickup_address || "",
    dropoff_address: queryParams.dropoff_address || queryParams.dropoff_address || "",
    type: queryParams.type || "course_fixed",
    start_time: queryParams.start_time || queryParams.start_time || "",
    adults_count: queryParams.adults_count ? parseInt(queryParams.adults_count) : 1,
    large_luggage_count: 0,
    small_luggage_count: 0,
    luggage_count: queryParams.luggage_count ? parseInt(queryParams.luggage_count) : 0,
    notes: queryParams.notes || ""
  });
  useEffect(() => {
    if (data.type === "event_hourly") {
      setData("dropoff_address", "");
    }
  }, [data.type]);
  const handleSubmit = (e) => {
    e.preventDefault();
    transform((data2) => ({
      ...data2,
      luggage_count: data2.large_luggage_count + data2.small_luggage_count,
      notes: data2.notes + `

[Bagages : ${data2.large_luggage_count} grandes (23kg), ${data2.small_luggage_count} petites]`
    }));
    post(route("devis.store"));
  };
  return /* @__PURE__ */ jsxs(
    "form",
    {
      onSubmit: handleSubmit,
      className: "space-y-6 bg-white p-8 rounded-3xl shadow-xl border border-slate-100",
      children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 border-b border-slate-100 pb-6", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "user_name",
                value: "Votre Nom ",
                className: "font-semibold text-slate-700"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "user_name",
                type: "text",
                value: data.user_name,
                onChange: (e) => setData("user_name", e.target.value),
                className: "mt-1 block w-full bg-slate-50 border-slate-200 focus:bg-white",
                disabled: !!auth.user,
                placeholder: "Votre Nom"
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.user_name, className: "mt-1" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "user_email",
                value: "Adresse Email",
                className: "font-semibold text-slate-700"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "user_email",
                type: "email",
                value: data.user_email,
                onChange: (e) => setData("user_email", e.target.value),
                className: "mt-1 block w-full bg-slate-50 border-slate-200 focus:bg-white",
                disabled: !!auth.user,
                placeholder: "votre adresse mail"
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.user_email, className: "mt-1" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: "type",
              value: "Type de prestation",
              className: "font-semibold text-slate-700 mb-2"
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3", children: [
            { id: "course_fixed", label: "Course Forfaitaire" },
            {
              id: "event_hourly",
              label: "Location Horaire"
            }
          ].map((item) => /* @__PURE__ */ jsxs(
            "label",
            {
              className: `flex items-center justify-center p-4 rounded-xl border-2 cursor-pointer transition-all font-bold text-sm ${data.type === item.id ? "border-amber-500 bg-amber-50/50 text-slate-900 shadow-sm" : "border-slate-100 bg-white text-slate-500 hover:border-slate-200"}`,
              children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "radio",
                    name: "type",
                    value: item.id,
                    checked: data.type === item.id,
                    onChange: () => setData("type", item.id),
                    className: "sr-only"
                  }
                ),
                item.label
              ]
            },
            item.id
          )) }),
          /* @__PURE__ */ jsx(InputError, { message: errors.type, className: "mt-1" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "pickup_address",
                value: "Lieu de départ",
                className: "font-semibold text-slate-700"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "relative mt-1", children: [
              /* @__PURE__ */ jsx(MapPin, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" }),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "pickup_address",
                  type: "text",
                  value: data.pickup_address,
                  onChange: (e) => setData("pickup_address", e.target.value),
                  className: "pl-11 block w-full border-slate-200",
                  placeholder: "Ex: Aéroport Blaise Diagne (AIBD)"
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              InputError,
              {
                message: errors.pickup_address,
                className: "mt-1"
              }
            )
          ] }),
          data.type !== "event_hourly" && /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "dropoff_address",
                value: "Lieu de destination",
                className: "font-semibold text-slate-700"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "relative mt-1", children: [
              /* @__PURE__ */ jsx(MapPin, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-amber-500" }),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "dropoff_address",
                  type: "text",
                  value: data.dropoff_address,
                  onChange: (e) => setData("dropoff_address", e.target.value),
                  className: "pl-11 block w-full border-slate-200",
                  placeholder: "Ex: Hôtel Terrou-Bi, Dakar"
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              InputError,
              {
                message: errors.dropoff_address,
                className: "mt-1"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "start_time",
                value: "Date & Heure de départ",
                className: "font-semibold text-slate-700"
              }
            ),
            /* @__PURE__ */ jsx("div", { className: "relative mt-1", children: /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "start_time",
                type: "datetime-local",
                value: data.start_time,
                onChange: (e) => setData("start_time", e.target.value),
                className: " block w-full border-slate-200",
                required: true
              }
            ) }),
            /* @__PURE__ */ jsx(InputError, { message: errors.start_time, className: "mt-1" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                value: "Nombre de personnes",
                className: "font-semibold text-slate-700 mb-2"
              }
            ),
            /* @__PURE__ */ jsx("div", { className: "flex items-center", children: /* @__PURE__ */ jsx(
              StepperInput,
              {
                value: data.adults_count,
                onChange: (v) => setData("adults_count", v),
                min: 1,
                max: 7
              }
            ) }),
            /* @__PURE__ */ jsx(
              InputError,
              {
                message: errors.adults_count,
                className: "mt-1"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                value: "Bagages",
                className: "font-semibold text-slate-700 mb-2"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3 bg-slate-50 border border-slate-200 p-3 rounded-xl", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsx("span", { className: "text-sm text-slate-600 font-medium", children: "Grand (23kg max)" }),
                /* @__PURE__ */ jsx(
                  StepperInput,
                  {
                    value: data.large_luggage_count,
                    onChange: (v) => setData("large_luggage_count", v),
                    min: 0,
                    max: 5
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsx("span", { className: "text-sm text-slate-600 font-medium", children: "Petit" }),
                /* @__PURE__ */ jsx(
                  StepperInput,
                  {
                    value: data.small_luggage_count,
                    onChange: (v) => setData("small_luggage_count", v),
                    min: 0,
                    max: 4
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              InputError,
              {
                message: errors.luggage_count,
                className: "mt-1"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: "notes",
              value: "Instructions spéciales ou notes",
              className: "font-semibold text-slate-700"
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "relative mt-1", children: /* @__PURE__ */ jsx(
            "textarea",
            {
              id: "notes",
              value: data.notes,
              onChange: (e) => setData("notes", e.target.value),
              className: "block w-full rounded-lg  border-slate-200 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm p-3 min-h-[100px]",
              placeholder: "Ex: Besoin d'accueil personnalisé avec pancarte..."
            }
          ) }),
          /* @__PURE__ */ jsx(InputError, { message: errors.notes, className: "mt-1" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "pt-2", children: /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "w-full justify-center py-3.5 bg-amber-500 text-slate-900 hover:bg-slate-900 hover:text-white font-bold rounded-xl text-base transition-all shadow-lg shadow-amber-500/10",
            disabled: processing,
            children: processing ? "Envoi de votre demande..." : "Demander mon devis gratuit"
          }
        ) })
      ]
    }
  );
}
function DevisPage({ queryParams }) {
  return /* @__PURE__ */ jsxs(UserLayout, { transparent: false, children: [
    /* @__PURE__ */ jsx(Head, { title: "Demande de Devis Premium - Teranga Shuttle" }),
    /* @__PURE__ */ jsx("div", { className: "bg-slate-50 min-h-screen pt-28 pb-16 px-6", children: /* @__PURE__ */ jsxs("div", { className: "max-w-3xl mx-auto", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center mb-10", children: [
        /* @__PURE__ */ jsx("span", { className: "text-amber-500 font-bold uppercase tracking-widest text-xs px-3 py-1 bg-amber-100 rounded-full", children: "Service VIP" }),
        /* @__PURE__ */ jsx("h1", { className: "text-3xl md:text-4xl font-black text-slate-900 uppercase tracking-tighter mt-3", children: "Demande de Devis Personnalisé" }),
        /* @__PURE__ */ jsx("p", { className: "mt-3 text-slate-600 max-w-xl mx-auto text-sm md:text-base", children: "Planifiez votre déplacement en Mercedes Classe V avec chauffeur privé au Sénégal. Recevez une estimation claire sous 24h." })
      ] }),
      /* @__PURE__ */ jsx(DevisForm, { queryParams })
    ] }) })
  ] });
}
export {
  DevisPage as default
};
