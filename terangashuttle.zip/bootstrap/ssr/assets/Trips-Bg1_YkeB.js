import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useMemo } from "react";
import { U as UserLayout } from "./UserLayout-BtuPwiUA.js";
import { Head, Link } from "@inertiajs/react";
import { MapPin, Search, X, Compass, Clock, ArrowRight } from "lucide-react";
import "sonner";
function Trips({ trips }) {
  const [search, setSearch] = useState("");
  const filteredTrips = useMemo(() => {
    return trips.filter(
      (trip) => trip.departure_city.toLowerCase().includes(search.toLowerCase()) || trip.arrival_city.toLowerCase().includes(search.toLowerCase())
    );
  }, [trips, search]);
  const formatDuration = (minutes) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h ${mins}min` : `${hours}h`;
  };
  return /* @__PURE__ */ jsxs(UserLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Trajets Forfaitaires - Teranga Shuttle" }),
    /* @__PURE__ */ jsx("section", { className: "pt-32 pb-24 bg-slate-50/50 px-4 sm:px-6 min-h-screen", children: /* @__PURE__ */ jsxs("div", { className: "max-w-6xl mx-auto", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col mb-10", children: [
        /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-2 mb-3", children: [
          /* @__PURE__ */ jsx(MapPin, { className: "w-4 h-4 text-amber-500" }),
          /* @__PURE__ */ jsx("span", { className: "text-xs font-black uppercase tracking-widest text-slate-400", children: "Catalogue de prix" })
        ] }),
        /* @__PURE__ */ jsxs("h1", { className: "text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight mb-4", children: [
          "Tarifs &",
          " ",
          /* @__PURE__ */ jsx("span", { className: "italic font-serif text-amber-500", children: "Trajets Forfaitaires" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-slate-500 max-w-2xl font-light", children: "Découvrez nos itinéraires prédéfinis avec des tarifs fixes et transparents. Pas de mauvaise surprise, le prix est garanti à la réservation." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "bg-white border border-slate-200 rounded-[1.5rem] p-3 shadow-[0_10px_30px_-15px_rgba(0,0,0,0.05)] mb-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "relative w-full sm:max-w-md group", children: [
          /* @__PURE__ */ jsx(Search, { className: "absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-amber-500 transition-colors" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              placeholder: "Rechercher une ville (ex: Saly, AIBD)...",
              value: search,
              onChange: (e) => setSearch(e.target.value),
              className: "w-full h-12 pl-14 pr-10 bg-slate-50/50 border-none rounded-xl text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:ring-2 focus:ring-amber-500/20 focus:bg-white transition-all"
            }
          ),
          search && /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setSearch(""),
              className: "absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-slate-600 bg-slate-100 rounded-lg transition-colors",
              children: /* @__PURE__ */ jsx(X, { className: "w-4 h-4" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-xs font-bold text-slate-400 tracking-wider uppercase px-4", children: [
          filteredTrips.length,
          " résultat",
          filteredTrips.length > 1 ? "s" : ""
        ] })
      ] }),
      filteredTrips.length > 0 ? /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6", children: filteredTrips.map((trip) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: "bg-white rounded-[2rem] border border-slate-100 p-6 shadow-[0_4px_20px_-10px_rgba(0,0,0,0.05)] hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.1)] hover:border-amber-500/30 transition-all duration-300 flex flex-col justify-between group relative",
          children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 text-amber-600 text-[10px] font-black uppercase tracking-wider mb-6", children: [
                /* @__PURE__ */ jsx(Compass, { className: "w-3.5 h-3.5" }),
                "Prix Garanti"
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "relative pl-6 space-y-5 before:absolute before:left-2 before:top-2.5 before:bottom-2.5 before:w-[2px] before:bg-slate-100 mb-8", children: [
                /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsx("div", { className: "absolute -left-[29px] top-1.5 w-3 h-3 rounded-full border-[3px] border-amber-500 bg-white shadow-sm" }),
                  /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase font-bold tracking-widest text-slate-400 mb-1", children: "Départ" }),
                  /* @__PURE__ */ jsx("p", { className: "text-base font-bold text-slate-900", children: trip.departure_city })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsx("div", { className: "absolute -left-[29px] top-1.5 w-3 h-3 rounded-full border-[3px] border-slate-300 bg-white shadow-sm group-hover:border-slate-900 transition-colors" }),
                  /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase font-bold tracking-widest text-slate-400 mb-1", children: "Destination" }),
                  /* @__PURE__ */ jsx("p", { className: "text-base font-bold text-slate-900", children: trip.arrival_city })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "pt-5 border-t border-slate-100", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs font-medium text-slate-400 mb-4", children: [
                /* @__PURE__ */ jsx(Clock, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxs("span", { children: [
                  "Durée : ~",
                  formatDuration(
                    trip.estimated_duration_minutes
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-end justify-between", children: [
                /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs("p", { className: "text-xl font-black text-slate-900 tracking-tight", children: [
                  Number(
                    trip.fixed_price
                  ).toLocaleString(),
                  /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-amber-500 ml-1", children: "FCFA" })
                ] }) }),
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route(
                      "booking.trip.details",
                      {
                        trip_id: trip.id,
                        type: "course_fixed"
                      }
                    ),
                    className: "w-10 h-10 flex items-center justify-center bg-slate-50 text-slate-900 rounded-xl hover:bg-slate-950 hover:text-white transition-all active:scale-90",
                    children: /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4 group-hover:-rotate-45 transition-transform" })
                  }
                )
              ] })
            ] })
          ]
        },
        trip.id
      )) }) : (
        /* Empty State */
        /* @__PURE__ */ jsxs("div", { className: "bg-white border border-dashed border-slate-200 rounded-[2rem] py-20 text-center max-w-2xl mx-auto", children: [
          /* @__PURE__ */ jsx("div", { className: "w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsx(MapPin, { className: "w-8 h-8 text-slate-300" }) }),
          /* @__PURE__ */ jsx("h3", { className: "text-lg font-bold text-slate-900 mb-2", children: "Aucun itinéraire trouvé" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm text-slate-500 max-w-md mx-auto mb-6", children: "Nous ne disposons pas de tarif forfaitaire pour cette recherche. Vous pouvez tout de même demander un devis personnalisé." }),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setSearch(""),
              className: "px-6 py-2.5 bg-slate-950 text-white text-xs font-bold uppercase tracking-wider rounded-xl hover:bg-amber-500 hover:text-slate-950 transition-colors",
              children: "Afficher tous les trajets"
            }
          )
        ] })
      )
    ] }) })
  ] });
}
export {
  Trips as default
};
