import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { usePage, Link } from "@inertiajs/react";
import { toast, Toaster } from "sonner";
import { LayoutDashboard, CalendarDays, RoadIcon, Wallet, Car, LogOut, Menu } from "lucide-react";
function AuthenticatedLayout({ children }) {
  const { auth, flash } = usePage().props;
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  useEffect(() => {
    if (flash.success) toast.success(flash.success);
    if (flash.error) toast.error(flash.error);
  }, [flash]);
  const navigation = [
    {
      name: "Dashboard",
      href: route("admin.index"),
      icon: LayoutDashboard
    },
    {
      name: "Réservations",
      href: route("admin.booking.index"),
      icon: CalendarDays
    },
    { name: "Trajets", href: route("admin.trips.index"), icon: RoadIcon },
    { name: "Paiements", href: route("admin.payment.index"), icon: Wallet }
  ];
  return /* @__PURE__ */ jsxs("div", { className: "flex h-screen bg-slate-50 overflow-hidden", children: [
    isSidebarOpen && /* @__PURE__ */ jsx(
      "div",
      {
        className: "fixed inset-0 bg-black/50 z-40 lg:hidden",
        onClick: () => setIsSidebarOpen(false)
      }
    ),
    /* @__PURE__ */ jsx(
      "aside",
      {
        className: `fixed lg:static inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out ${isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`,
        children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col h-full", children: [
          /* @__PURE__ */ jsx("div", { className: "h-16 flex items-center px-6 border-b border-slate-800", children: /* @__PURE__ */ jsxs(Link, { href: "/", className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Car, { className: "text-amber-500 w-7 h-7" }),
            /* @__PURE__ */ jsx("span", { className: "text-lg font-black tracking-tight uppercase", children: "Teranga" })
          ] }) }),
          /* @__PURE__ */ jsx("nav", { className: "flex-1 px-4 py-6 space-y-1", children: navigation.map((item) => {
            const active = route().current(item.href);
            return /* @__PURE__ */ jsxs(
              Link,
              {
                href: item.href,
                className: `flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${active ? "bg-amber-500 text-slate-900" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`,
                children: [
                  /* @__PURE__ */ jsx(item.icon, { className: "w-4 h-4" }),
                  item.name
                ]
              },
              item.name
            );
          }) }),
          /* @__PURE__ */ jsx("div", { className: "p-4 border-t border-slate-800", children: /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("admin.auth.logout"),
              method: "post",
              as: "button",
              className: "flex items-center gap-3 w-full px-4 py-2 text-slate-400 hover:text-red-400 text-sm font-medium",
              children: [
                /* @__PURE__ */ jsx(LogOut, { className: "w-4 h-4" }),
                "Déconnexion"
              ]
            }
          ) })
        ] })
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "flex-1 flex flex-col h-screen overflow-hidden", children: [
      /* @__PURE__ */ jsxs("header", { className: "h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 shrink-0", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setIsSidebarOpen(!isSidebarOpen),
            className: "p-2 lg:hidden text-slate-600 hover:bg-slate-100 rounded-lg",
            children: /* @__PURE__ */ jsx(Menu, { className: "w-6 h-6" })
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 ml-auto", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-right hidden md:block", children: [
            /* @__PURE__ */ jsx("p", { className: "text-sm font-bold text-slate-900", children: auth.user.name }),
            /* @__PURE__ */ jsx("p", { className: "text-[10px] text-slate-500 uppercase tracking-wider", children: auth.user.email })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "w-9 h-9 rounded-full bg-amber-500 text-slate-900 flex items-center justify-center font-bold text-sm", children: auth.user.name.charAt(0).toUpperCase() })
        ] })
      ] }),
      /* @__PURE__ */ jsx("main", { className: "flex-1 overflow-y-auto p-4 lg:p-8", children: /* @__PURE__ */ jsx("div", { className: "max-w-7xl mx-auto", children }) })
    ] }),
    /* @__PURE__ */ jsx(Toaster, { position: "top-right", richColors: true, closeButton: true })
  ] });
}
export {
  AuthenticatedLayout as A
};
