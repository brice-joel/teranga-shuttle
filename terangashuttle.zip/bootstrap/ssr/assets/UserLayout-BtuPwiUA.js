import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { usePage, Link } from "@inertiajs/react";
import { Home, Map, Briefcase, Calendar, Compass, Car, LogOut, Menu, X, User, ArrowUpRight, Phone, Mail, FileText, MessageCircle } from "lucide-react";
import { toast, Toaster } from "sonner";
function UserLayout({ children, transparent = false }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isFabOpen, setIsFabOpen] = useState(false);
  const { auth } = usePage().props;
  const { url } = usePage();
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 30);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  const navLinks = [
    { name: "Accueil", href: route("home"), icon: Home },
    { name: "Nos Trajets", href: route("trips"), icon: Map },
    { name: "Services", href: route("services"), icon: Briefcase },
    { name: "Événements", href: route("events"), icon: Calendar },
    { name: "Contact", href: route("contact"), icon: Compass }
  ];
  const { flash } = usePage().props;
  useEffect(() => {
    if (flash.success) toast.success(flash.success);
    if (flash.error) toast.error(flash.error);
  }, [flash]);
  const isActive = (href) => url === new URL(href).pathname;
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-slate-50/50 flex flex-col antialiased text-slate-900 font-sans", children: [
    /* @__PURE__ */ jsx(
      "header",
      {
        className: `fixed top-0 w-full z-[80] transition-all duration-500 ${isScrolled ? "bg-white/75 backdrop-blur-xl border-b border-slate-200/40 shadow-[0_2px_20px_-4px_rgba(0,0,0,0.03)] py-3" : transparent ? "bg-transparent py-5" : "bg-white border-b border-slate-100 py-4"}`,
        children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 flex justify-between items-center", children: [
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: "/",
              className: "flex items-center gap-2.5 group transition-transform active:scale-98",
              children: [
                /* @__PURE__ */ jsx(
                  "div",
                  {
                    className: `p-2 rounded-xl transition-all duration-300 ${isScrolled || !transparent ? "bg-slate-950 text-amber-500" : "bg-white/10 text-white backdrop-blur-md"}`,
                    children: /* @__PURE__ */ jsx(Car, { className: "w-5 h-5 group-hover:rotate-[-4deg] transition-transform" })
                  }
                ),
                /* @__PURE__ */ jsxs(
                  "span",
                  {
                    className: `text-xl font-black uppercase tracking-tighter transition-colors duration-300 ${isScrolled || !transparent ? "text-slate-950" : "text-white"}`,
                    children: [
                      "Teranga",
                      /* @__PURE__ */ jsx("span", { className: "text-amber-500 italic font-serif font-medium lowercase tracking-normal pl-0.5", children: "shuttle" })
                    ]
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsx("nav", { className: "hidden md:flex items-center gap-8", children: navLinks.map((link) => {
            const active = isActive(link.href);
            return /* @__PURE__ */ jsxs(
              Link,
              {
                href: link.href,
                className: `relative text-xs font-bold uppercase tracking-widest py-2 transition-all duration-300 hover:text-amber-500 ${active ? "text-amber-500" : isScrolled || !transparent ? "text-slate-600" : "text-white/80 hover:text-white"}`,
                children: [
                  link.name,
                  active && /* @__PURE__ */ jsx("span", { className: "absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-[2px] bg-amber-500 rounded-full" })
                ]
              },
              link.name
            );
          }) }),
          /* @__PURE__ */ jsx("div", { className: "hidden md:flex items-center gap-4", children: auth.user ? /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxs(
              Link,
              {
                href: route("bookings.index"),
                className: `px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all duration-300 flex items-center gap-2 border active:scale-98 ${isScrolled || !transparent ? "bg-slate-950 hover:bg-slate-900 border-transparent text-white shadow-md shadow-slate-950/10" : "bg-white/10 backdrop-blur-md text-white border-white/20 hover:bg-white hover:text-slate-950"}`,
                children: [
                  /* @__PURE__ */ jsx("span", { className: "w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" }),
                  "Mes réservations"
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              Link,
              {
                href: route("logout"),
                method: "post",
                as: "button",
                className: "p-2.5 rounded-xl border border-slate-200 text-slate-400 hover:text-red-500 hover:border-red-100 hover:bg-red-50/50 transition-all active:scale-95",
                title: "Déconnexion",
                children: /* @__PURE__ */ jsx(LogOut, { className: "w-4 h-4" })
              }
            )
          ] }) : /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-5", children: [
            /* @__PURE__ */ jsx(
              Link,
              {
                href: route("login"),
                className: `text-xs font-black uppercase tracking-wider transition-colors hover:text-amber-500 ${isScrolled || !transparent ? "text-slate-900" : "text-white"}`,
                children: "Connexion"
              }
            ),
            /* @__PURE__ */ jsx(
              Link,
              {
                href: route("register"),
                className: "bg-amber-500 text-slate-950 px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider hover:bg-slate-950 hover:text-white transition-all duration-300 shadow-md shadow-amber-500/10 active:scale-98",
                children: "S'inscrire"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setIsMobileMenuOpen(true),
              className: `md:hidden p-2 rounded-xl transition-all active:scale-90 ${isScrolled || !transparent ? "text-slate-950 bg-slate-100" : "text-white bg-white/10 backdrop-blur-md"}`,
              children: /* @__PURE__ */ jsx(Menu, { className: "w-5 h-5" })
            }
          )
        ] })
      }
    ),
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: `fixed inset-0 z-[100] transition-all duration-500 ${isMobileMenuOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`,
        children: [
          /* @__PURE__ */ jsx(
            "div",
            {
              className: "absolute inset-0 bg-slate-950/40 backdrop-blur-sm transition-opacity",
              onClick: () => setIsMobileMenuOpen(false)
            }
          ),
          /* @__PURE__ */ jsxs(
            "aside",
            {
              className: `absolute right-0 top-0 h-full w-full sm:w-85 bg-white shadow-2xl transform transition-transform duration-500 cubic-bezier(0.16, 1, 0.3, 1) flex flex-col ${isMobileMenuOpen ? "translate-x-0" : "translate-x-full"}`,
              children: [
                /* @__PURE__ */ jsxs("div", { className: "p-5 flex justify-between items-center border-b border-slate-100", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsx("div", { className: "bg-amber-500/10 p-1.5 rounded-lg text-amber-600", children: /* @__PURE__ */ jsx(Car, { className: "w-4 h-4" }) }),
                    /* @__PURE__ */ jsx("span", { className: "font-black text-sm uppercase tracking-wider text-slate-950", children: "Menu Teranga Shuttle" })
                  ] }),
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      onClick: () => setIsMobileMenuOpen(false),
                      className: "p-2 bg-slate-50 hover:bg-slate-100 text-slate-500 rounded-xl transition-all active:scale-90",
                      children: /* @__PURE__ */ jsx(X, { className: "w-4 h-4" })
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx("nav", { className: "flex-1 px-4 py-6 space-y-1 overflow-y-auto", children: navLinks.map((link) => {
                  const LinkIcon = link.icon;
                  const active = isActive(link.href);
                  return /* @__PURE__ */ jsxs(
                    Link,
                    {
                      href: link.href,
                      className: `flex items-center gap-4 px-4 py-3.5 rounded-xl font-bold text-sm tracking-wide transition-all ${active ? "bg-amber-500/10 text-amber-600" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"}`,
                      onClick: () => setIsMobileMenuOpen(false),
                      children: [
                        /* @__PURE__ */ jsx(
                          LinkIcon,
                          {
                            className: `w-4 h-4 ${active ? "text-amber-500" : "text-slate-400"}`
                          }
                        ),
                        link.name
                      ]
                    },
                    link.name
                  );
                }) }),
                /* @__PURE__ */ jsx("div", { className: "p-5 border-t border-slate-100 bg-slate-50/50 space-y-3", children: auth.user ? /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsxs(
                    Link,
                    {
                      href: route("bookings.index"),
                      className: "flex items-center justify-between w-full px-4 py-3.5 bg-slate-950 text-white rounded-xl font-bold text-xs uppercase tracking-wider transition-all active:scale-98 shadow-md",
                      onClick: () => setIsMobileMenuOpen(false),
                      children: [
                        /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-2", children: [
                          /* @__PURE__ */ jsx(User, { className: "w-4 h-4 text-slate-400" }),
                          "Mes réservations"
                        ] }),
                        /* @__PURE__ */ jsx(ArrowUpRight, { className: "w-4 h-4 text-amber-500" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxs(
                    Link,
                    {
                      href: route("profile.edit"),
                      className: "flex items-center justify-between w-full px-4 py-3.5 bg-slate-950 text-white rounded-xl font-bold text-xs uppercase tracking-wider transition-all active:scale-98 shadow-md",
                      onClick: () => setIsMobileMenuOpen(false),
                      children: [
                        /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-2", children: [
                          /* @__PURE__ */ jsx(User, { className: "w-4 h-4 text-slate-400" }),
                          "Mon profil"
                        ] }),
                        /* @__PURE__ */ jsx(ArrowUpRight, { className: "w-4 h-4 text-amber-500" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxs(
                    Link,
                    {
                      href: route("logout"),
                      method: "post",
                      as: "button",
                      className: "flex items-center justify-center gap-2 w-full py-3.5 text-xs font-bold text-red-600 border border-red-100 bg-red-50 rounded-xl transition-all active:scale-98",
                      onClick: () => setIsMobileMenuOpen(false),
                      children: [
                        /* @__PURE__ */ jsx(LogOut, { className: "w-4 h-4" }),
                        "Déconnexion"
                      ]
                    }
                  )
                ] }) : /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
                  /* @__PURE__ */ jsx(
                    Link,
                    {
                      href: route("login"),
                      className: "flex items-center justify-center py-3.5 font-bold text-xs uppercase tracking-wider border border-slate-200 text-slate-700 bg-white rounded-xl transition-all active:scale-98",
                      onClick: () => setIsMobileMenuOpen(false),
                      children: "Connexion"
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    Link,
                    {
                      href: route("register"),
                      className: "flex items-center justify-center py-3.5 font-black text-xs uppercase tracking-wider bg-amber-500 text-slate-950 rounded-xl transition-all shadow-md shadow-amber-500/5 active:scale-98",
                      onClick: () => setIsMobileMenuOpen(false),
                      children: "S'inscrire"
                    }
                  )
                ] }) })
              ]
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsx("main", { className: "flex-grow", children }),
    /* @__PURE__ */ jsx("footer", { className: "bg-slate-950 text-white pt-16 pb-8 border-t border-slate-900", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-12 gap-10 md:gap-6 pb-12 border-b border-slate-900", children: [
        /* @__PURE__ */ jsxs("div", { className: "md:col-span-4 space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-xl font-black uppercase tracking-tighter", children: [
            "Teranga",
            /* @__PURE__ */ jsx("span", { className: "text-amber-500 italic font-serif font-medium lowercase tracking-normal pl-0.5", children: "shuttle" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-slate-400 text-xs leading-relaxed max-w-sm", children: "L'excellence globale du transport VIP au Sénégal. Voyagez en toute sérénité dans le confort absolu de nos flottes premium." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "md:col-span-3 md:pl-8", children: [
          /* @__PURE__ */ jsx("h4", { className: "font-bold text-xs uppercase tracking-widest text-slate-200 mb-4", children: "Services" }),
          /* @__PURE__ */ jsx("ul", { className: "space-y-2.5 text-xs text-slate-400 font-medium", children: [
            "Transferts Aéroport",
            "Location Horaire",
            "Événements VIP",
            "Tourisme de Luxe"
          ].map((item) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
            "a",
            {
              href: "#",
              className: "hover:text-amber-500 transition-all inline-block hover:translate-x-0.5",
              children: item
            }
          ) }, item)) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "md:col-span-2", children: [
          /* @__PURE__ */ jsx("h4", { className: "font-bold text-xs uppercase tracking-widest text-slate-200 mb-4", children: "Support" }),
          /* @__PURE__ */ jsx("ul", { className: "space-y-2.5 text-xs text-slate-400 font-medium", children: [
            "Aide & FAQ",
            "Réservations",
            "Conditions Générales",
            "Confidentialité"
          ].map((item) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
            "a",
            {
              href: "#",
              className: "hover:text-amber-500 transition-all inline-block hover:translate-x-0.5",
              children: item
            }
          ) }, item)) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "md:col-span-3 space-y-3.5", children: [
          /* @__PURE__ */ jsx("h4", { className: "font-bold text-xs uppercase tracking-widest text-slate-200 mb-4", children: "Contact" }),
          /* @__PURE__ */ jsxs("ul", { className: "space-y-3 text-xs text-slate-400 font-medium", children: [
            /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2.5", children: [
              /* @__PURE__ */ jsx("div", { className: "p-1.5 rounded-lg bg-slate-900 text-amber-500", children: /* @__PURE__ */ jsx(Phone, { className: "w-3.5 h-3.5" }) }),
              /* @__PURE__ */ jsx("span", { children: "+221 77 000 00 00" })
            ] }),
            /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2.5", children: [
              /* @__PURE__ */ jsx("div", { className: "p-1.5 rounded-lg bg-slate-900 text-amber-500", children: /* @__PURE__ */ jsx(Mail, { className: "w-3.5 h-3.5" }) }),
              /* @__PURE__ */ jsx("span", { className: "truncate", children: "contact@teranga-shuttle.sn" })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-[11px] font-medium text-slate-500", children: [
        /* @__PURE__ */ jsx("p", { children: "© 2026 Teranga Shuttle Sénégal. Façonné avec soin." }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-4 font-bold uppercase tracking-wider text-slate-600", children: [
          /* @__PURE__ */ jsx("span", { children: "Sénégal" }),
          /* @__PURE__ */ jsx("span", { className: "text-amber-500/40", children: "•" }),
          /* @__PURE__ */ jsx("span", { children: "Afrique" })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "fixed bottom-5 right-5 z-[90] flex flex-col items-end gap-2.5 pm-safe", children: [
      /* @__PURE__ */ jsxs(
        "div",
        {
          className: `flex flex-col gap-2.5 transition-all duration-300 origin-bottom transform ${isFabOpen ? "opacity-100 scale-100 translate-y-0" : "opacity-0 scale-90 translate-y-4 pointer-events-none"}`,
          children: [
            /* @__PURE__ */ jsxs(
              Link,
              {
                href: route("devis.index"),
                className: "flex items-center gap-3 bg-white/90 backdrop-blur-md text-slate-900 pl-4 pr-2.5 py-1.5 rounded-xl shadow-[0_4px_20px_-2px_rgba(0,0,0,0.08)] border border-slate-200/50 hover:bg-white hover:border-slate-300 transition-all font-bold text-xs group active:scale-95",
                onClick: () => setIsFabOpen(false),
                children: [
                  /* @__PURE__ */ jsx("span", { className: "text-slate-600 font-semibold group-hover:text-slate-900", children: "Demande de devis" }),
                  /* @__PURE__ */ jsx("div", { className: "bg-amber-500/10 p-2 rounded-lg text-amber-600 group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors", children: /* @__PURE__ */ jsx(FileText, { className: "w-3.5 h-3.5" }) })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              "a",
              {
                href: "https://wa.me/+41763233400",
                target: "_blank",
                rel: "noopener noreferrer",
                className: "flex items-center gap-3 bg-white/90 backdrop-blur-md text-slate-900 pl-4 pr-2.5 py-1.5 rounded-xl shadow-[0_4px_20px_-2px_rgba(0,0,0,0.08)] border border-slate-200/50 hover:bg-white hover:border-slate-300 transition-all font-bold text-xs group active:scale-95",
                onClick: () => setIsFabOpen(false),
                children: [
                  /* @__PURE__ */ jsx("span", { className: "text-slate-600 font-semibold group-hover:text-slate-900", children: "WhatsApp VIP" }),
                  /* @__PURE__ */ jsx("div", { className: "bg-emerald-500/10 p-2 rounded-lg text-emerald-600 group-hover:bg-emerald-500 group-hover:text-white transition-colors", children: /* @__PURE__ */ jsx(MessageCircle, { className: "w-3.5 h-3.5 fill-current" }) })
                ]
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setIsFabOpen(!isFabOpen),
          className: `w-12 h-12 rounded-xl flex items-center justify-center shadow-xl transition-all duration-300 active:scale-90 ${isFabOpen ? "bg-slate-950 text-white rotate-90 shadow-slate-950/20" : "bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-amber-500/20"}`,
          "aria-label": "Menu de contact",
          children: isFabOpen ? /* @__PURE__ */ jsx(X, { className: "w-4 h-4" }) : /* @__PURE__ */ jsx(MessageCircle, { className: "w-4.5 h-4.5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsx(Toaster, { position: "top-right", richColors: true, closeButton: true })
  ] });
}
export {
  UserLayout as U
};
