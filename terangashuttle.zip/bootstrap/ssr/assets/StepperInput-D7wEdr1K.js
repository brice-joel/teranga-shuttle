import { jsxs, jsx } from "react/jsx-runtime";
import { Minus, Plus } from "lucide-react";
function StepperInput({
  value,
  onChange,
  min = 0,
  max = 100
}) {
  const decrement = () => {
    if (value > min) {
      onChange(value - 1);
    }
  };
  const increment = () => {
    if (value < max) {
      onChange(value + 1);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center space-x-3 bg-white rounded-lg border border-slate-200 p-1", children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        onClick: decrement,
        disabled: value <= min,
        className: "p-1.5 rounded-md bg-slate-50 text-slate-600 hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
        children: /* @__PURE__ */ jsx(Minus, { className: "w-4 h-4" })
      }
    ),
    /* @__PURE__ */ jsx("span", { className: "font-bold text-slate-900 w-6 text-center text-sm", children: value }),
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        onClick: increment,
        disabled: value >= max,
        className: "p-1.5 rounded-md bg-slate-50 text-slate-600 hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
        children: /* @__PURE__ */ jsx(Plus, { className: "w-4 h-4" })
      }
    )
  ] });
}
export {
  StepperInput as S
};
