import { jsxs, jsx } from "react/jsx-runtime";
import { U as UserLayout } from "./UserLayout-BtuPwiUA.js";
import { Head, Link } from "@inertiajs/react";
import { CheckCircle, Clock, PhoneCall, ArrowRight } from "lucide-react";
import { f as formatDate } from "./formatters-Dx77TuBc.js";
import "react";
import "sonner";
function Confirmation({ booking }) {
  return /* @__PURE__ */ jsxs(UserLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Réservation reçue" }),
    /* @__PURE__ */ jsx("section", { className: "pt-40 pb-20 px-6 min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxs("div", { className: "max-w-3xl w-full text-center space-y-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative inline-block", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-amber-500 blur-2xl opacity-20 animate-pulse" }),
        /* @__PURE__ */ jsx(
          CheckCircle,
          {
            className: "w-24 h-24 text-amber-500 relative mx-auto",
            strokeWidth: 1
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("h1", { className: "text-5xl font-black uppercase italic tracking-tighter", children: [
          "Demande",
          " ",
          /* @__PURE__ */ jsx("span", { className: "text-amber-500", children: "Reçue !" })
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "text-slate-500 text-lg max-w-xl mx-auto font-medium", children: [
          "Votre réservation pour le",
          " ",
          /* @__PURE__ */ jsx("span", { className: "text-slate-900 font-bold", children: formatDate(booking.start_time) }),
          " ",
          "est en cours d'examen par notre équipe technique."
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6 mt-12 text-left", children: [
        /* @__PURE__ */ jsxs("div", { className: "bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm", children: [
          /* @__PURE__ */ jsx(Clock, { className: "w-8 h-8 text-amber-500 mb-4" }),
          /* @__PURE__ */ jsx("h4", { className: "font-black uppercase text-xs tracking-widest mb-2", children: "Prochaine étape" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm text-slate-500 leading-relaxed", children: "Un chauffeur va valider la disponibilité. Dès validation, vous recevrez un lien pour finaliser votre paiement sécurisé." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-slate-900 p-8 rounded-[2.5rem] text-white", children: [
          /* @__PURE__ */ jsx(PhoneCall, { className: "w-8 h-8 text-amber-500 mb-4" }),
          /* @__PURE__ */ jsx("h4", { className: "font-black uppercase text-xs tracking-widest mb-2 text-slate-400", children: "Besoin d'aide ?" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm text-slate-300 leading-relaxed", children: "Notre équipe peut vous contacter par téléphone d'ici quelques minutes pour confirmer les détails de votre prise en charge." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "pt-8 flex flex-col md:flex-row items-center justify-center gap-6", children: [
        /* @__PURE__ */ jsx(
          Link,
          {
            href: "/",
            className: "text-xs font-black uppercase tracking-[0.2em] text-slate-400 hover:text-amber-500 transition-colors",
            children: "Retour à l'accueil"
          }
        ),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("booking.index"),
            className: "bg-amber-500 text-slate-900 px-10 py-5 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center gap-3 shadow-xl shadow-amber-500/20 hover:bg-white transition-all group",
            children: [
              "Suivre ma réservation",
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4 group-hover:translate-x-1 transition-transform" })
            ]
          }
        )
      ] })
    ] }) })
  ] });
}
export {
  Confirmation as default
};
