<?php

use App\Http\Middleware\AuthAdminMiddleware;
use App\Http\Middleware\AuthMiddleware;
use App\Http\Middleware\LogoutIfAuthentificatedMiddleware;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        //AUTH MIDDLEWARE
        $middleware->alias([
            'auth' => AuthMiddleware::class, // auth middleware
            'logout_if_authenticated' => LogoutIfAuthentificatedMiddleware::class,
            'auth_admin' => AuthAdminMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
