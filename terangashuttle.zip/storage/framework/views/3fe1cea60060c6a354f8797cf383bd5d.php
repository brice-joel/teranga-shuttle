
<?php $__env->startSection('title', 'reservations'); ?>

<?php $__env->startSection('content'); ?>



    <section class="py-16 bg-gray-100">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg p-8">
                <div class="flex justify-between items-center mb-8">
                    <div>
                        <h2 class="text-3xl font-semibold text-gray-800 mb-2">
                            <i class="fas fa-file-invoice mr-2 text-blue-500"></i> Facture N° <?php echo e($data_reservation->id); ?>

                        </h2>
                        <p class="text-sm text-gray-600">Date : <?php echo e(date('d/m/Y')); ?></p>
                    </div>
                    <div class="text-right">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo teranga shuttle"
                            class="w-20 h-20 rounded-full mx-auto">
                    </div>
                </div>

                <div class="mb-10">
                    <h3 class="text-2xl font-semibold mb-6 text-gray-800">
                        <i class="fas fa-user mr-2 text-blue-500"></i> Informations du Client
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <p class="text-gray-700"><strong class="font-medium">Nom :</strong> <?php echo e(Auth::user()->name); ?></p>
                        <p class="text-gray-700"><strong class="font-medium">Email :</strong> <?php echo e(Auth::user()->email); ?>

                        </p>
                        <p class="text-gray-700"><strong class="font-medium">Téléphone :</strong>
                            <?php echo e(Auth::user()->phone); ?></p>
                    </div>
                </div>

                <div class="mb-10">
                    <h3 class="text-2xl font-semibold mb-6 text-gray-800">
                        <i class="fas fa-info-circle mr-2 text-blue-500"></i> Informations de la Réservation
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <p class="text-gray-700">
                            <strong class="font-medium">Type de réservation :</strong> <?php echo e($data_reservation->type); ?>

                        </p>
                        <?php if($data_reservation->type == 'trajet'): ?>
                            <p class="text-gray-700"><strong class="font-medium">Départ :</strong>
                                <?php echo e($data_reservation->start); ?></p>
                            <p class="text-gray-700"><strong class="font-medium">Destination :</strong>
                                <?php echo e($data_reservation->destination); ?></p>
                        <?php else: ?>
                            <p class="text-gray-700"><strong class="font-medium">Course :</strong>
                                <?php echo e($data_reservation->label); ?></p>
                        <?php endif; ?>
                        <p class="text-gray-700"><strong class="font-medium">Date de Réservation :</strong>
                            <?php echo e($data_reservation->start_date); ?></p>
                        <p class="text-gray-700"><strong class="font-medium">Heure de Réservation :</strong>
                            <?php echo e($data_reservation->start_hour); ?></p>
                        <div class="uppercase">
                            <strong class="font-medium">Statut :</strong>
                            <?php if($data_reservation->status == 'en attente'): ?>
                                <span
                                    class="bg-yellow-100 text-yellow-800 text-xs font-medium me-2 px-2.5 py-1 rounded-full">
                                    <?php echo e($data_reservation->status); ?>

                                </span>
                            <?php elseif($data_reservation->status == 'confirmer'): ?>
                                <span class="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-1 rounded-full">
                                    <?php echo e($data_reservation->status); ?>

                                </span>
                            <?php elseif($data_reservation->status == 'annuler'): ?>
                                <span class="bg-red-100 text-red-800 text-xs font-medium me-2 px-2.5 py-1 rounded-full">
                                    <?php echo e($data_reservation->status); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <p class="text-gray-700"><strong class="font-medium">Durée moyenne :</strong> 20 Minutes</p>
                        <p class="text-gray-700"><strong class="font-medium">Nb Passagers :</strong>
                            <?php echo e($data_reservation->places); ?>

                        </p>
                        <p class="text-gray-700"><strong class="font-medium">Baggages :</strong>
                            <?php echo e($data_reservation->luggage); ?></p>

                        <p class="text-xl font-bold text-gray-800">
                            <strong class="font-medium">Prix :</strong> <span
                                class="underline"><?php echo e($data_reservation->price); ?> XOF</span>
                        </p>
                    </div>
                </div>

                <div class="text-center mt-8">
                    <?php if($data_reservation->status == 'en attente'): ?>
                        <div class="flex flex-col md:flex-row justify-center items-center gap-4">
                            <form action="<?php echo e(route('payment.create-checkout-session')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="amount" value="<?php echo e($data_reservation->price); ?>" readonly
                                    required>
                                <input type="number" name="id_reservation" value="<?php echo e($data_reservation->id); ?>" hidden
                                    required>
                                <button
                                    class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-xl transition-colors text-lg flex items-center">
                                    <i class="fas fa-credit-card mr-2"></i> Payer maintenant
                                </button>
                            </form>

                            <form action="<?php echo e(route('reservation.cancel', $data_reservation->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button type="submit"
                                    class="bg-red-500 hover:bg-red-600 text-white font-semibold py-3 px-8 rounded-xl transition-colors text-sm flex items-center">
                                    <i class="fas fa-times-circle mr-2"></i> Annuler la réservation
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\teranga-shuttle\teranga-shuttle\teranga-shuttle\resources\views/reservation/index.blade.php ENDPATH**/ ?>