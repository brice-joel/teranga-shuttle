<?php
    function minutesToHoursMinutes($minutes)
    {
        $heures = floor($minutes / 60);
        $minutesRestantes = $minutes % 60;

        return sprintf('%d heure(s) %d minute(s)', $heures, $minutesRestantes);
    }
?>



<?php $__env->startSection('title', 'confirmation de réservation'); ?>

<?php $__env->startSection('style'); ?>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #97690d;
            border-bottom: 2px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 20px;
            text-align: center;
        }

        .section-title {
            color: #97690d;
            margin-top: 25px;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .info {
            margin-bottom: 20px;
        }

        .info strong {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .details {
            background-color: #f0f8ff;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }

        .footer {
            margin-top: 30px;
            text-align: center;
            color: #777;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('app-title'); ?>
    <span>Confirmation de réservation </span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="container">

        <div class="details">
            <h2 class="section-title">Informations de Réservation</h2>
            <div class="info"><strong>Numéro de Réservation:</strong> <?php echo e($data_reservation->id); ?></div>
            <div class="info"><strong>Réservation:</strong>
                <?php if($data_reservation->type == 'trajet'): ?>
                    <?php echo e($data_reservation->start); ?> -> <?php echo e($data_reservation->destination); ?>

                <?php endif; ?>
                <?php if($data_reservation->type == 'ride'): ?>
                    <?php echo e($data_reservation->label); ?>

                <?php endif; ?>
            </div>
            <div class="info"><strong>Type de Réservation:</strong> <?php echo e($data_reservation->type); ?></div>
            <div class="info"><strong>Date:</strong> <?php echo e($data_reservation->start_date); ?> </div>
            <div class="info"><strong>Heure:</strong> <?php echo e($data_reservation->start_hour); ?> </div>
            <div class="info"><strong>Durée:</strong> <?php echo e(minutesToHoursMinutes($data_reservation->duration)); ?> </div>
            <div class="info"><strong>Prix :</strong> <?php echo e($data_reservation->price); ?> XOF</div>
        </div>

        <div class="details">
            <h2 class="section-title">Informations Client</h2>
            <div class="info"><strong>Nom du Client:</strong> <?php echo e($data_reservation->name); ?></div>
            <div class="info"><strong>Téléphone:</strong> <?php echo e($data_reservation->phone); ?></div>
            <div class="info"><strong>Email:</strong><?php echo e($data_reservation->email); ?></div>
        </div>

        <div class="details">
            <h2 class="section-title">Détails Supplémentaires</h2>
            <div class="info"><strong>Nombre de Personnes:</strong> <?php echo e($data_reservation->places); ?> personnes</div>
            <div class="info"><strong>Bagages:</strong> <?php echo e($data_reservation->luggage); ?> </div>
            <div class="info"><strong>Voiture:</strong> Mercedez Classe V220 </div>
        </div>

        <div class="footer">
            <p>Merci pour votre réservation !</p>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\teranga-shuttle\teranga-shuttle\teranga-shuttle\resources\views/emails/confirm_reservation.blade.php ENDPATH**/ ?>