
<?php $__env->startSection('content'); ?>
    <section>
        <div class="bg-white shadow-md rounded-lg p-6">
            <h1 class="text-2xl font-semibold text-gray-800 mb-6">
                Créer un Trajet

            </h1>
            <?php echo $__env->make('admin.trajet.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\teranga-shuttle\teranga-shuttle\teranga-shuttle\resources\views/admin/trajet/create.blade.php ENDPATH**/ ?>