<!DOCTYPE html>
<html>

<head>
    <title>Paiement Stripe</title>
    <script src="https://js.stripe.com/v3/"></script>
</head>

<body>
    <h1>Paiement de 10 €</h1>

    <!--
    <form id="payment-form">
        <div id="payment-element">
        </div>
        <button id="submit">Payer</button>
        <div id="error-message">
        </div>
    </form>
-->
    <form action="<?php echo e(route('create-checkout-session')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="amount">Montant (EUR)</label>
        <input type="number" name="amount" id="amount" min="1" step="0.01" required>
        <button type="submit">Payer</button>
    </form>

    <script>
        /*
                const stripe = Stripe('<?php echo e(env('STRIPE_KEY')); ?>');
                const elements = stripe.elements();
                const paymentElement = elements.create('payment');
                paymentElement.mount('#payment-element');

                const form = document.getElementById('payment-form');
                const submitButton = document.getElementById('submit');
                const errorMessage = document.getElementById('error-message');

                form.addEventListener('submit', async (event) => {
                    event.preventDefault();

                    const {
                        error
                    } = await stripe.confirmPayment({
                        elements,
                        confirmParams: {
                            return_url: '<?php echo e(route('payment.checkout-success')); ?>',
                        },
                    });

                    if (error) {
                        errorMessage.textContent = error.message;
                    } else {
                        // Le paiement a réussi
                    }
                });
                */
    </script>
</body>

</html>
<?php /**PATH D:\Project\teranga-shuttle\teranga-shuttle\teranga-shuttle\resources\views/payment/test.blade.php ENDPATH**/ ?>