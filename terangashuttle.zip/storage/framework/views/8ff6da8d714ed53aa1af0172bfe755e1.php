
<?php $__env->startSection('title', 'teranga-shuttle contact'); ?>
<?php $__env->startSection('content'); ?>

    <section class="py-16 bg-gray-100">
        <div class="container mx-auto px-4">
            <h1 class="text-4xl font-semibold text-center mb-10 text-gray-800">Contactez-nous</h1>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div class="p-6 bg-white rounded-2xl shadow-md">
                    <h2 class="text-3xl font-semibold mb-6 text-gray-900">Informations de contact</h2>
                    <p class="text-gray-700 mb-4 flex items-center">
                        <i class="fa-solid fa-map-marker-alt mr-3 text-gray-500"></i> 123 Rue de l'Exemple, Ville, Pays
                    </p>
                    <p class="text-gray-700 mb-4 flex items-center">
                        <i class="fa-solid fa-phone mr-3 text-gray-500"></i> +1 234 567 890
                    </p>
                    <p class="text-gray-700 mb-6 flex items-center">
                        <i class="fa-solid fa-envelope mr-3 text-gray-500"></i> info@terangashuttle.com
                    </p>
                    <div class="mt-8">
                        <h3 class="text-lg font-semibold mb-4 text-gray-800">Suivez-nous</h3>
                        <div class="flex space-x-6">
                            <a href="#" class="text-blue-500 hover:text-blue-700 transition-colors">
                                <i class="fa-brands fa-facebook-f text-2xl"></i>
                            </a>
                            <a href="#" class="text-blue-400 hover:text-blue-600 transition-colors">
                                <i class="fa-brands fa-twitter text-2xl"></i>
                            </a>
                            <a href="#" class="text-red-500 hover:text-red-700 transition-colors">
                                <i class="fa-brands fa-instagram text-2xl"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="p-6 bg-white rounded-2xl shadow-md">
                    <h2 class="text-3xl font-semibold mb-6 text-gray-900">Envoyez-nous un message</h2>
                    <form action="<?php echo e(route('mail.form_contact')); ?>" method="POST" class="space-y-6">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label for="name" class="block text-sm font-medium text-gray-700">Nom</label>
                            <input type="text" name="name" id="name" value="<?php echo e(Auth::user()->name); ?>"
                                class="mt-1 p-3 w-full border rounded-xl focus:ring-blue-500 focus:border-blue-500"
                                required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <br>
                                <span class="text-red-700 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                            <input type="email" name="email" id="email" value="<?php echo e(Auth::user()->email); ?>"
                                class="mt-1 p-3 w-full border rounded-xl focus:ring-blue-500 focus:border-blue-500"
                                required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <br>
                                <span class="text-red-700 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label for="message" class="block text-sm font-medium text-gray-700">Message</label>
                            <textarea name="message" id="message" rows="4" required
                                class="mt-1 p-3 w-full border rounded-xl focus:ring-blue-500 focus:border-blue-500"><?php echo e(old('message')); ?></textarea>
                        </div>
                        <div>
                            <button type="submit"
                                class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-6 rounded-xl transition-colors w-full">
                                Envoyer
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\teranga-shuttle\teranga-shuttle\teranga-shuttle\resources\views/contact.blade.php ENDPATH**/ ?>