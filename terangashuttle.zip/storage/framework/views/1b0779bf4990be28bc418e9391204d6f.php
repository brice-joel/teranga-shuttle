 <form method="POST" action="<?php echo e($trajet->id ? route('admin.trajet.update', $trajet) : route('admin.trajet.store')); ?>"
     class="space-y-4">
     <?php if($trajet->id): ?>
         <?php echo method_field('PUT'); ?>
     <?php endif; ?>

     <?php echo csrf_field(); ?>
     <div>
         <label for="start" class="block text-gray-700 text-sm font-bold mb-2">Départ</label>
         <input type="text" name="start" id="start" value="<?php echo e(old('start', $trajet->start)); ?>" required
             class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
             placeholder="Ville de départ">
         <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
             <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
     </div>

     <div>
         <label for="destination" class="block text-gray-700 text-sm font-bold mb-2">Destination</label>
         <input type="text" name="destination" id="destination"
             value="<?php echo e(old('destination', $trajet->destination)); ?>" required
             class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
             placeholder="Ville de destination">
         <?php $__errorArgs = ['destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
             <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
     </div>

     <div>
         <label for="price" class="block text-gray-700 text-sm font-bold mb-2">Prix (FCFA)</label>
         <input type="number" name="price" id="price" value="<?php echo e(old('price', $trajet->price)); ?>" required
             class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
             placeholder="Prix du trajet">
         <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
             <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
     </div>

     <div>
         <label for="duree_moyenne" class="block text-gray-700 text-sm font-bold mb-2">Durée Moyenne
             (minutes)</label>
         <input type="number" name="duration" id="duration" value="<?php echo e(old('duration', $trajet->duration)); ?>" required
             class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
             placeholder="Durée moyenne du trajet en minutes">
         <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
             <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
     </div>

     <div class="flex justify-end">
         <button type="submit"
             class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
             <i class="fas fa-save mr-2"></i> Enregistrer
         </button>
         <a href="<?php echo e(route('admin.trajet.index')); ?>"
             class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline ml-2">
             <i class="fas fa-times mr-2"></i> Annuler
         </a>
     </div>
 </form>
<?php /**PATH D:\Project\teranga-shuttle\teranga-shuttle\teranga-shuttle\resources\views/admin/trajet/form.blade.php ENDPATH**/ ?>