
<?php $__env->startSection('content'); ?>
    <section>
        <h1>Liste de Réservations</h1>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\teranga-shuttle\teranga-shuttle\teranga-shuttle\resources\views/admin/reservations.blade.php ENDPATH**/ ?>