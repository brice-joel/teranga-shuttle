@extends('template')
@section('content')
    <section class="bg-gradient-to-r from-blue-100 to-gold-100 py-12 px-4 min-h-screen">
        <div class="flex justify-center items-center w-full md:inset-0 max-h-full">
            <div class="w-full  max-w-2xl max-h-full">
                <div class="bg-gray-300 rounded-3xl shadow-2xl p-8 md:p-12">

                    <div class="text-center  mb-8">
                        <h3 class="text-3xl font-extrabold text-indigo-700 mb-4">
                            <i class="fas fa-calendar-alt mr-2"></i> Réservation
                        </h3>
                        <p class="text-gray-600">Veuillez remplir les détails de votre réservation.</p>
                    </div>

                    <div class="mb-8 border-b border-gray-200">
                        @if ($type == 'ride')
                            <h3 class="text-2xl font-semibold text-gray-800 pb-4">
                                <i class="fas fa-car mr-2"></i> Location :
                                <span class="font-bold uppercase">{{ request()->query('label') }}</span>
                                <span class="text-4xl font-bold text-blue-600 ml-2">
                                    <strong class="price">{{ request()->query('price') }}</strong> XOF
                                </span>
                            </h3>
                        @elseif ($type == 'trajet')
                            <h3 class="text-2xl font-semibold text-gray-800 pb-4">
                                <i class="fas fa-route mr-2"></i> Trajet :
                                <span class="font-bold uppercase">{{ request()->query('start') }}</span>
                                <i class="fas fa-arrow-right mx-2"></i>
                                <span class="font-bold uppercase">{{ request()->query('destination') }}</span>
                                <span class="text-4xl font-bold text-blue-600 ml-2">
                                    <strong class="price">{{ request()->query('price') }}</strong> XOF
                                </span>
                            </h3>
                        @endif
                    </div>

                    <form method="POST" action="{{ route('reservation.store') }}" class="space-y-6" id="formReservation">
                        @csrf

                        <input type="hidden" name="type" readonly value="{{ $type }}">
                        <input type="hidden" name="type_id" readonly value="{{ $type_id }}">
                        <input type="hidden" name="price" readonly class="price"
                            value="{{ request()->query('price') }}">

                        <div>
                            <label for="phone" class="block mb-2 text-sm font-medium text-gray-900">
                                <i class="fas fa-phone mr-2"></i> Téléphone
                            </label>
                            <input type="tel" name="phone" id="phone" placeholder="Ex: +243 999 999 999"
                                class="bg-gray-50 border border-gray-300 px-4 py-3 text-gray-900 text-sm rounded-xl focus:ring-blue-500 focus:border-blue-500 block w-full"
                                value="{{ Auth::user()->phone }}" readonly disabled required />
                            @error('phone')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>



                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                            <div>
                                <label for="luggage" class="block mb-2 text-sm font-medium text-gray-900">
                                    <i class="fas fa-suitcase mr-2"></i> Bagages
                                </label>
                                <select id="luggage" name="luggage"
                                    class="w-full border rounded-xl px-4 py-3 text-gray-900 bg-gray-50 focus:ring-blue-500 focus:border-blue-500">
                                    <option value="">---------</option>
                                    <option value="non">Non</option>
                                    <option value="oui">Oui</option>
                                </select>
                                @error('luggage')
                                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label for="places" class="block mb-2 text-sm font-medium text-gray-900">
                                    <i class="fas fa-users mr-2"></i> Nombre de Passagers
                                </label>
                                <select name="places" id="places"
                                    class="w-full border rounded-xl bg-gray-50 px-4 py-3 text-gray-900 focus:ring-blue-500 focus:border-blue-500">
                                    @for ($i = 1; $i <= 8; $i++)
                                        <option value="{{ $i }}">{{ $i }}</option>
                                    @endfor
                                </select>
                                @error('places')
                                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                @enderror
                            </div>


                        </div>



                        <div class="flex flex-col md:flex-row gap-6">
                            <div class="flex-1">
                                <label for="start_date" class="block mb-2 text-sm font-medium text-gray-900">
                                    <i class="fas fa-calendar-day mr-2"></i> Date de Réservation
                                </label>
                                <input type="date" name="start_date" id="start_date"
                                    class="w-full bg-gray-50 border border-gray-300 px-4 py-3 text-gray-900 text-sm rounded-xl focus:ring-blue-500 focus:border-blue-500"
                                    value="{{ old('start_date') }}" required />
                                @error('start_date')
                                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <div class="flex-1">
                                <label for="start_hour" class="block mb-2 text-sm font-medium text-gray-900">
                                    <i class="fas fa-clock mr-2"></i> Heure de Réservation
                                </label>
                                <select name="start_hour" id="start_hour"
                                    class="w-full bg-gray-50 border border-gray-300 px-4 py-3 text-gray-900 text-sm rounded-xl focus:ring-blue-500 focus:border-blue-500"
                                    required>
                                    @if (old('start_hour'))
                                        <option value="{{ old('start_hour') }}" selected>{{ old('start_hour') }}</option>
                                    @endif
                                </select>
                                @error('start_hour')
                                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>



                        <div>
                            <label for="comment" class="block mb-2 text-sm font-medium text-gray-900">
                                <i class="fas fa-comment-alt mr-2"></i> Commentaire
                            </label>
                            <textarea name="comment" id="comment" placeholder="Ajouter un commentaire"
                                class="w-full text-gray-900 bg-gray-50 border border-gray-300 rounded-xl px-4 py-3 focus:ring-blue-500 focus:border-blue-500"></textarea>
                        </div>



                        <button type="submit"
                            class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-xl text-sm px-5 py-3 transition-colors">
                            <i class="fas fa-check mr-2"></i> Réserver
                        </button>
                    </form>



                </div>
            </div>
        </div>
    </section>
@endsection

@section('script')
    <script>
        // script for time field and date field
        //document.addEventListener('DOMContentLoaded', function() {});

        $(document).ready(function() {
            function populateHours() {
                var select = $('#start_hour');
                select.empty();

                var now = new Date();
                var currentHour = now.getHours();
                var currentMinute = now.getMinutes();
                var next30Minutes = new Date(now.getTime() + 30 * 60 * 1000); // Ajoute 30 minutes
                var nextHour = next30Minutes.getHours();
                var nextMinute = next30Minutes.getMinutes();

                for (var hour = 4; hour < 22; hour++) {
                    for (var minute = 0; minute < 60; minute += 30) {
                        var formattedHour = (hour < 10 ? '0' : '') + hour;
                        var formattedMinute = (minute < 10 ? '0' : '') + minute;
                        var time = formattedHour + ':' + formattedMinute;
                        select.append('<option value="' + time + '">' + time + '</option>');
                    }
                }

                // Définir l'heure par défaut sur l'heure actuelle + 30 minutes
                if (!"{{ old('start_hour') }}") {
                    var defaultHour = (nextHour < 10 ? '0' : '') + nextHour;
                    var defaultMinute = (nextMinute < 10 ? '0' : '') + nextMinute;
                    var defaultTime = defaultHour + ':' + defaultMinute;
                    select.val(defaultTime);
                }

            }

            populateHours();
        });

        $(document).ready(function() {
            var today = new Date().toISOString().split('T')[0];
            $('#start_date').attr('min', today);
        });
    </script>

    <script>
        /* script for update price */
        $(document).ready(function() {
            $('#places').change(function() {
                var selectedPlaces = parseInt($(this).val());
                var originalPrice = parseInt("{{ request()->query('price') }}");
                var newPrice = originalPrice;

                if (selectedPlaces > 4) {
                    newPrice += 50000;
                }

                $('.price').text(newPrice); //for title
                $('.price').val(newPrice); // for input
            });

        });
    </script>
@endsection
