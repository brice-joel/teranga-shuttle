<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginFormResquest;
use App\Http\Requests\RegisterFormRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

use function PHPSTORM_META\type;

class AuthController extends Controller
{
    //
    public function register(): View
    {
        return view('auth.register');
    }

    public function doRegister(RegisterFormRequest $request)
    {
        // dd($request->validated());
        // dd($request->phone);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'phone' => $request->phone,
        ]);

        Auth::login($user);

        return redirect()->route('index')->with('success', 'Inscription réussie !'); // Rediriger vers la page d'accueil ou une autre page
    }

    public function login(): View
    {
        return view('auth.login');
    }
    public function doLogin(LoginFormResquest $request)
    {
        $credentials = $request->validated();
        $remember = $request->has('remember');

        if (Auth::attempt($credentials, $remember)) {
            $request->session()->regenerate();
            return redirect()->intended(route('index'))->with('success', 'Connexion réussie !');
        }

        return back()->withErrors([
            'password' => 'Identifiant ou mot de passe incorrect',
        ])->onlyInput('password', 'email');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('index')->with('success', 'Deconnexion réussie !');
    }
}
