<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class MyController extends Controller
{
    //
    public function index(): View
    {
        //pagination reservations
        $reservations = DB::table('reservations')
            ->join('trajets', 'trajets.id', '=', 'reservations.trajet_id')
            ->join('users', 'users.id', '=', 'reservations.user_id')
            ->select('reservations.id',  'reservations.date', 'reservations.hour', 'reservations.status', 'users.name', 'users.email', 'trajets.depart', 'trajets.destination', 'trajets.prix', 'trajets.duree',)
            ->orderBy('reservations.date', 'desc')
            ->orderBy('reservations.hour', 'desc')
            ->paginate(4);
        // ->get()->all();
        //dd($reservations);
        return view('admin.dashboard', ['reservations' => $reservations]);
    }
}
